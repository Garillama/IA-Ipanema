"""Pinned public upstream test data, never a runtime skill or a host mount."""
import hashlib
import json
from pathlib import Path
from .core import IpanemaError
from .snapshot_links import symlink_free


def verified_upstream_fixture(root, skill):
    from .coordinator import EXTERNAL_SKILLS
    if skill != 'better-accessibility':
        raise IpanemaError('Fixture upstream no autorizado.')
    root=Path(root)
    directory=root/'tests/fixtures/upstream'/skill
    manifest=directory/'provenance.json'
    if not symlink_free(manifest,root) or not manifest.is_file() or manifest.stat().st_size>50_000:
        raise IpanemaError('Fixture upstream ausente o con symlink.')
    try:
        def unique(pairs):
            value={}
            for key,item in pairs:
                if key in value:raise ValueError('duplicate')
                value[key]=item
            return value
        provenance=json.loads(manifest.read_text(encoding='utf-8'),object_pairs_hook=unique)
        meta=EXTERNAL_SKILLS[skill]
        expected={'SKILL.md':meta['source_sha1'],**meta['references_sha1'],
                  'agents/openai.yaml':meta['agents_yaml_sha1']}
        if provenance['kind']!='offline-upstream-fixture' or provenance['skill']!=skill:
            raise ValueError('identity')
        for key in ('source_repo','source_path','source_commit','license'):
            if provenance[key]!=meta[key]:raise ValueError('provenance')
        if set(provenance['files'])!=set(expected):raise ValueError('files')
        for name,blob_sha in expected.items():
            path=directory/name
            if not symlink_free(path,root) or not path.is_file() or path.stat().st_size>200_000:
                raise ValueError('file')
            data=path.read_bytes();row=provenance['files'][name]
            sha256=hashlib.sha256(data).hexdigest()
            actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
            if (actual!=blob_sha or row['git_blob_sha1']!=blob_sha
                or row['sha256']!=sha256 or row['bytes']!=len(data)):
                raise ValueError('hash')
            if name=='SKILL.md' and sha256!=meta['source_sha256']:raise ValueError('hash')
    except (ValueError,KeyError,TypeError,OSError) as exc:
        raise IpanemaError('Integridad/procedencia del fixture upstream rechazada.') from None
    return directory
