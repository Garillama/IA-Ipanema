"""Explicit receipts for historical evidence intentionally excluded from offline QA.

Receipts assert identity/existence only. They never validate evidence contents,
Google state, runtime results, new links or a changed document.
"""
from pathlib import Path
import re
from urllib.parse import unquote
from .core import beneath, digest, now, IpanemaError


def symlink_free(path, root):
    """Check lexical components before resolving any symlink target."""
    try:relative=path.relative_to(root)
    except ValueError:return False
    if any(part in ('.','..') for part in relative.parts):return False
    cursor=root
    if cursor.is_symlink():return False
    for part in relative.parts:
        cursor=cursor/part
        if cursor.is_symlink():return False
    return True


def capture_omitted_links(source, snapshot):
    rows=[]
    for document in snapshot.rglob('*.md'):
        rel=document.relative_to(snapshot)
        original=source/rel
        if not original.is_file() or not symlink_free(original,source) or not symlink_free(document,snapshot) or digest(original)!=digest(document):continue
        for match in re.finditer(r'(?<!!)\[[^\]]+\]\((<[^>]+>|[^\s)]+)\)',document.read_text(encoding='utf-8')):
            raw=unquote(match.group(1).strip('<>').partition('#')[0])
            if re.match(r'^[a-zA-Z]+://|^mailto:|^app:',raw) or Path(raw).is_absolute():continue
            # Line/anchor semantics cannot be established from identity receipts.
            if re.search(r':\d+$',raw) or '#' in match.group(1):continue
            target=(document.parent/raw).resolve()
            if not beneath(target,snapshot/'reports/runs') or target.exists():continue
            relative=target.relative_to(snapshot)
            if any(part.startswith('.') for part in relative.parts) or target.name.endswith('.local.json') or target.suffix not in ('.md','.json'):continue
            original_target=source/relative
            if not original_target.is_file() or not symlink_free(original_target,source):continue
            rows.append({'source':rel.as_posix(),'source_sha256':digest(document),'destination':relative.as_posix(),
                         'destination_sha256':digest(original_target),'exists_at_capture':True})
    return {'kind':'controller-offline-snapshot-links','at':now(),'scope':'identity_only_contents_excluded','links':rows}


def verify_omitted_link_receipts(source, snapshot, manifest):
    """Recheck controller receipts against real source bytes before offline QA.

    Excluded artifacts stay outside the sandbox. This proves identity only;
    it never claims that the recorded contents are correct or approved.
    """
    if (not isinstance(manifest,dict) or manifest.get('kind')!='controller-offline-snapshot-links'
        or manifest.get('scope')!='identity_only_contents_excluded'
        or not isinstance(manifest.get('links'),list)):
        raise IpanemaError('Recibos históricos del controlador inválidos.')
    for row in manifest['links']:
        if not isinstance(row,dict) or row.get('exists_at_capture') is not True:
            raise IpanemaError('Recibo histórico sin existencia acreditada.')
        for key in ('source','destination'):
            value=row.get(key)
            if (not isinstance(value,str) or not value or Path(value).is_absolute()
                or '..' in Path(value).parts or '\\' in value):
                raise IpanemaError('Ruta del recibo histórico rechazada.')
        document=source/row['source']; copied=snapshot/row['source']
        target=source/row['destination']
        if (not beneath(target,source/'reports/runs') or target.suffix not in ('.md','.json')
            or any(p.startswith('.') for p in Path(row['destination']).parts)
            or target.name.endswith('.local.json')):
            raise IpanemaError('Destino del recibo histórico fuera de alcance.')
        for path,root,key in [(document,source,'source_sha256'),(copied,snapshot,'source_sha256'),
                              (target,source,'destination_sha256')]:
            expected=row.get(key)
            if (not isinstance(expected,str) or not re.fullmatch('[0-9a-f]{64}',expected)
                or not symlink_free(path,root) or not path.is_file() or digest(path)!=expected):
                raise IpanemaError('Hash o existencia de evidencia histórica no acreditados.')
    return manifest


def omitted_link_receipt(project, document, destination, *, manifest=None, strict_source=False):
    # Explicit QA caller opts in; editable project JSON never enables exclusions.
    if strict_source or project.theme_root is not None:return None
    if not symlink_free(document,project.root) or not symlink_free(destination,project.root):return None
    if not isinstance(manifest,dict) or manifest.get('kind')!='controller-offline-snapshot-links' or manifest.get('scope')!='identity_only_contents_excluded':return None
    if not beneath(document,project.root) or not beneath(destination,project.root/'reports/runs'):return None
    rel=destination.relative_to(project.root)
    if any(part.startswith('.') for part in rel.parts) or destination.name.endswith('.local.json') or destination.suffix not in ('.md','.json'):return None
    relative=document.relative_to(project.root).as_posix(); target=rel.as_posix()
    rows=manifest.get('links')
    if not isinstance(rows,list):return None
    for row in rows:
        if not isinstance(row,dict):continue
        if row.get('source')!=relative or row.get('destination')!=target or row.get('exists_at_capture')is not True:continue
        if not all(isinstance(row.get(k),str) and re.fullmatch('[0-9a-f]{64}',row[k]) for k in ('source_sha256','destination_sha256')):continue
        if digest(document)==row['source_sha256']:return row
    return None
