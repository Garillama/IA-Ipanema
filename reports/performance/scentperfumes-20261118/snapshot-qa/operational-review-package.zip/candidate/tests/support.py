"""Proyectos sintéticos: no contienen código propietario ni credenciales reales."""
from __future__ import annotations
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))


def put(path: Path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) if not isinstance(value, str) else value, encoding="utf-8")


def make_project(root: Path, identifier="sample", *, theme=True):
    put(root / "projects/registry.json", {"schema_version": 2, "default": identifier,
                                        "projects": {identifier: f"projects/{identifier}.json"}})
    put(root / f"projects/{identifier}.json", {"schema_version": 2, "id": identifier, "name": identifier,
        "theme_root": "theme" if theme else None, "discovery_root": "ipanema-discovery",
        "knowledge_reference_project": identifier, "evidence_dir": f"reports/runs/{identifier}",
        "public_url": "https://example.invalid", "qa": {"pages": {"home": "/"}}})
    if theme:
        put(root / "theme/layouts/layout.tpl", '<main>{% include "sections/hero.tpl" %}</main>')
        put(root / "theme/config/settings_schema.json", [])
        put(root / "theme/templates/pages/home.json", {"sections": {"hero": {"type": "hero", "settings": {}}}, "order": ["hero"]})
        put(root / "theme/sections/hero.tpl", '<section><h1>Fixture</h1></section>\n{% schema %}{"name":"Hero","settings":[{"id":"title","type":"setting","setting_type":"text","default":"Fixture"}]}{% endschema %}')
        put(root / "theme/manifest.json", {"theme": "fixture", "theme_version": "1", "forked": True})
    # Synthetic instructions keep strict production loading testable offline.
    # These do not authorize real provider execution or copy store information.
    from ipanema.coordinator import AUTHORIZED_SKILLS
    for skill in AUTHORIZED_SKILLS:
        put(root / ".agents/skills" / skill / "SKILL.md",
            "---\nname: " + skill + "\ndescription: Synthetic offline fixture\n---\n")
    return root


def historical_trio_policy(test):
    """Explicit offline v1 replay; never authorizes real CLI/provider execution."""
    from unittest.mock import patch
    value={'mode':'multi-agent','enabled':True,'members':['claude','codex','commandcode'],'disabled':[],
           'require_both_for_major_decisions':True,'independent_proposals':True,'cross_examination':True,
           'require_defense':False,'evidence_based_decisions':True,'max_deliberation_rounds':2,
           'production_requires_human_authorization':True}
    handle=patch('ipanema.orchestration.adapters.agent_policy',return_value=value)
    handle.start();test.addCleanup(handle.stop)


def validate_test_repository(project):
    """Explicit snapshot scope for test callers; ordinary validate remains strict."""
    from ipanema.validation import validate
    manifest=project.root/'qa-snapshot-links.json'
    receipts=json.loads(manifest.read_text()) if manifest.is_file() else None
    return validate(project,snapshot_receipts=receipts)
