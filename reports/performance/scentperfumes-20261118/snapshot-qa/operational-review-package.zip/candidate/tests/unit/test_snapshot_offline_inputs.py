"""Offline controller inputs: real pinned public fixtures, synthetic negative cases."""
import copy,json,shutil,tempfile,unittest
from pathlib import Path
from tests.support import ROOT
from ipanema.core import IpanemaError
from ipanema.qa_fixtures import verified_upstream_fixture
from ipanema.snapshot_links import capture_omitted_links,verify_omitted_link_receipts

class UpstreamFixture(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name)
  self.fixture=self.root/'tests/fixtures/upstream/better-accessibility';shutil.copytree(ROOT/'tests/fixtures/upstream/better-accessibility',self.fixture)
 def test_valid_pinned_fixture_without_host_local(self):
  self.assertEqual(verified_upstream_fixture(self.root,'better-accessibility'),self.fixture);self.assertFalse((self.root/'.local').exists())
 def test_missing_fixture_rejected(self):
  shutil.rmtree(self.fixture)
  with self.assertRaises(IpanemaError):verified_upstream_fixture(self.root,'better-accessibility')
 def test_tampered_skill_rejected(self):
  (self.fixture/'SKILL.md').write_text('not original')
  with self.assertRaises(IpanemaError):verified_upstream_fixture(self.root,'better-accessibility')
 def test_tampered_reference_rejected(self):
  (self.fixture/'forms.md').write_text('not original')
  with self.assertRaises(IpanemaError):verified_upstream_fixture(self.root,'better-accessibility')
 def test_symlink_rejected(self):
  target=self.fixture/'forms.md';data=target.read_bytes();target.unlink();(self.root/'outside').write_bytes(data);target.symlink_to(self.root/'outside')
  with self.assertRaises(IpanemaError):verified_upstream_fixture(self.root,'better-accessibility')
 def test_wrong_manifest_hash_rejected(self):
  p=self.fixture/'provenance.json';j=json.loads(p.read_text());j['files']['forms.md']['sha256']='0'*64;p.write_text(json.dumps(j))
  with self.assertRaises(IpanemaError):verified_upstream_fixture(self.root,'better-accessibility')
 def test_wrong_source_commit_rejected(self):
  p=self.fixture/'provenance.json';j=json.loads(p.read_text());j['source_commit']='0'*40;p.write_text(json.dumps(j))
  with self.assertRaises(IpanemaError):verified_upstream_fixture(self.root,'better-accessibility')
 def test_no_extra_files_or_paths_accepted(self):
  p=self.fixture/'provenance.json';j=json.loads(p.read_text());j['files']['../outside']={};p.write_text(json.dumps(j))
  with self.assertRaises(IpanemaError):verified_upstream_fixture(self.root,'better-accessibility')

class HistoricalInputs(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name);self.source=self.root/'source';self.view=self.root/'view'
  self.source.mkdir();self.view.mkdir();text='[History](reports/runs/old/report.json)'
  for p in [self.source,self.view]:(p/'README.md').write_text(text)
  self.target=self.source/'reports/runs/old/report.json';self.target.parent.mkdir(parents=True);self.target.write_text('{"synthetic":true}')
  self.manifest=capture_omitted_links(self.source,self.view)
 def test_valid_identity_receipt_with_excluded_content(self):
  self.assertEqual(verify_omitted_link_receipts(self.source,self.view,self.manifest),self.manifest);self.assertFalse((self.view/'reports/runs').exists())
 def test_missing_target_rejected(self):
  self.target.unlink()
  with self.assertRaises(IpanemaError):verify_omitted_link_receipts(self.source,self.view,self.manifest)
 def test_manipulated_target_rejected(self):
  self.target.write_text('changed')
  with self.assertRaises(IpanemaError):verify_omitted_link_receipts(self.source,self.view,self.manifest)
 def test_wrong_destination_hash_rejected(self):
  self.manifest['links'][0]['destination_sha256']='0'*64
  with self.assertRaises(IpanemaError):verify_omitted_link_receipts(self.source,self.view,self.manifest)
 def test_changed_document_rejected(self):
  (self.view/'README.md').write_text('changed')
  with self.assertRaises(IpanemaError):verify_omitted_link_receipts(self.source,self.view,self.manifest)
 def test_symlink_target_rejected(self):
  data=self.target.read_bytes();self.target.unlink();other=self.root/'outside';other.write_bytes(data);self.target.symlink_to(other)
  with self.assertRaises(IpanemaError):verify_omitted_link_receipts(self.source,self.view,self.manifest)
 def test_escape_rejected(self):
  self.manifest['links'][0]['destination']='../outside'
  with self.assertRaises(IpanemaError):verify_omitted_link_receipts(self.source,self.view,self.manifest)
 def test_missing_source_never_generates_receipt(self):
  self.target.unlink();self.assertEqual(capture_omitted_links(self.source,self.view)['links'],[])
