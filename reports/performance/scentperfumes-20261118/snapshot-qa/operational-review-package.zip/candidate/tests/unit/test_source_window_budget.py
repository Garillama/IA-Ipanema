"""Context windows must bound sent content without relaxing either prompt limit."""
import json,tempfile,unittest
from pathlib import Path
from tests.support import ROOT
from ipanema.core import Project,IpanemaError
from ipanema.orchestration.engine import prompt_for
class WindowBudget(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.tree=Path(self.tmp.name)
  self.plan={'_controller_instructions':{'rules':'Synthetic','skills':{}},'validation_plan':[],'objective':'Synthetic context'}
  self.task={'role':'audit','read_files':['large.txt'],'allowed_files':[]}
  (self.tree/'large.txt').write_text(('x'*500+'\n')*1000)
 def test_valid_excerpt_under_cap_with_complete_source_hash(self):
  self.plan['source_windows']={'large.txt':[[1,2]]};value=json.loads(prompt_for(Project(ROOT),self.plan,self.task,self.tree,[]));file=value['files']['large.txt'];self.assertFalse(file['full_content_in_prompt']);self.assertEqual(file['total_lines'],1000);self.assertEqual(len(file['sha256']),64);self.assertEqual(file['excerpts'][0]['content'],'x'*500+'\n'+'x'*500)
 def test_full_source_without_window_still_rejected(self):
  with self.assertRaises(IpanemaError):prompt_for(Project(ROOT),self.plan,self.task,self.tree,[])
 def test_excerpts_over_original_cap_rejected(self):
  (self.tree/'large.txt').write_text(('x'*2000+'\n')*300);self.plan['source_windows']={'large.txt':[[1,300]]}
  with self.assertRaises(IpanemaError):prompt_for(Project(ROOT),self.plan,self.task,self.tree,[])
 def test_combined_excerpt_budget_rejected(self):
  (self.tree/'large.txt').write_text(('x'*1000+'\n')*200);(self.tree/'second.txt').write_text(('y'*1000+'\n')*200);self.task['read_files'].append('second.txt');self.plan['source_windows']={'large.txt':[[1,200]],'second.txt':[[1,200]]}
  with self.assertRaises(IpanemaError):prompt_for(Project(ROOT),self.plan,self.task,self.tree,[])
 def test_invalid_windows_still_rejected(self):
  for windows in [[[0,1]],[[4,3]],[[1,1001]],[[1,400]],[[True,2]]]:
   self.plan['source_windows']={'large.txt':windows}
   with self.subTest(windows=windows),self.assertRaises(IpanemaError):prompt_for(Project(ROOT),self.plan,self.task,self.tree,[])
