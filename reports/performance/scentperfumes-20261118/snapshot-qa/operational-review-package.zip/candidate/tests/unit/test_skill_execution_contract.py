"""Offline controller contracts; mocked dispatch is not provider approval."""
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from tests.support import make_project
from ipanema.core import Project,IpanemaError
from ipanema.coordinator import AUTHORIZED_SKILLS,EXTERNAL_SKILLS,route
from ipanema.orchestration import engine,planner

class SkillExecutionContract(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=make_project(Path(self.tmp.name),theme=False)
        self.addCleanup(self.tmp.cleanup)
        (self.root/'AGENTS.md').write_text('Fixture rules. No remote actions.\n')
        (self.root/'copy.txt').write_text('Fixture content\n')
        for name in AUTHORIZED_SKILLS:
            p=self.root/'.agents/skills'/name/'SKILL.md';p.parent.mkdir(parents=True,exist_ok=True);p.write_text('---\nname: '+name+'\ndescription: fixture\n---\n')
        self.project=Project(self.root)

    def test_registered_skills_load_for_all_catalog_entries(self):
        names=sorted(AUTHORIZED_SKILLS)
        self.assertEqual(set(engine.instruction_context(self.project,{'skills':names})['skills']),set(names))

    def test_router_discovery_external_names_are_authorized(self):
        for request in ['Optimiza LCP','Auditoría integral de calidad web','Audita SEO canonical','Schema.org ProductGroup']:
            with self.subTest(request=request):
                names=route(request)['skills'];self.assertTrue(set(names)<=AUTHORIZED_SKILLS)
                self.assertEqual(set(engine.instruction_context(self.project,{'skills':names})['skills']),set(names))

    def test_unknown_names_including_ipanema_prefix_rejected(self):
        for name in ['ipanema-invented','cloudflare-unknown','unknown','../ipanema-architect','/etc/passwd','ipanema-architect/../../secret']:
            with self.subTest(name=name),self.assertRaises(IpanemaError):engine.instruction_context(self.project,{'skills':[name]})

    def test_list_type_entries_and_duplicates_rejected(self):
        for value in ['ipanema-architect',{},[None],[[]],['ipanema-architect','ipanema-architect']]:
            with self.subTest(value=value),self.assertRaises(IpanemaError):engine.instruction_context(self.project,{'skills':value})

    def test_missing_authorized_skill_fails_closed(self):
        (self.root/'.agents/skills/cloudflare-web-perf/SKILL.md').unlink()
        with self.assertRaises(IpanemaError):engine.instruction_context(self.project,{'skills':['cloudflare-web-perf']})

    def test_internal_and_external_file_symlinks_rejected(self):
        p=self.root/'.agents/skills/cloudflare-web-perf/SKILL.md';p.unlink()
        for dest in [self.root/'copy.txt',Path('/etc/hosts')]:
            with self.subTest(dest=str(dest)):
                p.symlink_to(dest)
                with self.assertRaises(IpanemaError):engine.instruction_context(self.project,{'skills':['cloudflare-web-perf']})
                p.unlink()

    def test_internal_directory_symlink_rejected(self):
        folder=self.root/'.agents/skills/cloudflare-web-perf';real=self.root/'relocated';folder.rename(real);folder.symlink_to(real,target_is_directory=True)
        with self.assertRaises(IpanemaError):engine.instruction_context(self.project,{'skills':['cloudflare-web-perf']})

    def test_invalid_utf8_fails_closed(self):
        (self.root/'.agents/skills/cloudflare-web-perf/SKILL.md').write_bytes(b'\xff')
        with self.assertRaises(IpanemaError):engine.instruction_context(self.project,{'skills':['cloudflare-web-perf']})

    def test_execute_reaches_configuration_only_after_catalog_validation(self):
        plan=planner.make_plan(self.project,'Optimiza LCP',files=['copy.txt'],scope='workspace',read_only=True)
        class DispatchReached(Exception):pass
        with patch.object(engine,'config',side_effect=DispatchReached),self.assertRaises(DispatchReached):engine.execute(self.project,plan,authorize=True)

    def test_execute_unknown_skill_never_dispatches(self):
        plan=planner.make_plan(self.project,'Revisa un texto',files=['copy.txt'],scope='workspace',read_only=True);plan['skills']=['ipanema-invented']
        with patch.object(engine,'config') as dispatch:
            with self.assertRaises(IpanemaError):engine.execute(self.project,plan,authorize=True)
            dispatch.assert_not_called()

    def test_sanitizer_keeps_private_default_and_explicit_qa_documents(self):
        (self.root/'.nuvem').write_text('synthetic-private');(self.root/'shop.local.json').write_text('{}')
        p=self.root/'.agents/skills/ipanema-invented/SKILL.md';p.parent.mkdir();p.write_text('Unregistered')
        view=engine.sanitized_view(self.root,self.root/'default-view',names=['.agents/skills/cloudflare-web-perf/SKILL.md','.nuvem','shop.local.json'])
        self.assertFalse((view/'.agents').exists());self.assertFalse((view/'.nuvem').exists())
        view=engine.sanitized_view(self.root,self.root/'qa-view',names=['.agents/skills/cloudflare-web-perf/SKILL.md','.agents/skills/ipanema-invented/SKILL.md','.nuvem','shop.local.json'],include_skills=True)
        self.assertTrue((view/'.agents/skills/cloudflare-web-perf/SKILL.md').is_file());self.assertFalse((view/'.agents/skills/ipanema-invented').exists());self.assertFalse((view/'.nuvem').exists());self.assertFalse((view/'shop.local.json').exists())

    def test_external_ancestor_symlink_rejected_in_context_and_qa(self):
        import shutil
        external=tempfile.TemporaryDirectory();self.addCleanup(external.cleanup)
        relocated=Path(external.name)/'instructions';shutil.move(str(self.root/'.agents'),relocated)
        (self.root/'.agents').symlink_to(relocated,target_is_directory=True)
        with self.assertRaises(IpanemaError):engine.instruction_context(self.project,{'skills':['cloudflare-web-perf']})
        view=engine.sanitized_view(self.root,self.root/'outside-view',names=['.agents/skills/cloudflare-web-perf/SKILL.md'],include_skills=True)
        self.assertFalse((view/'.agents').exists())

    def test_rules_symlink_rejected(self):
        rules=self.root/'AGENTS.md';rules.unlink();rules.symlink_to(self.root/'copy.txt')
        with self.assertRaises(IpanemaError):engine.instruction_context(self.project,{'skills':[]})

    def test_invalid_snapshot_records_blocked_before_qa_or_worker(self):
        engine.git(self.root,'init','-q');(self.root/'bad.md').write_bytes(b'\xff')
        engine.git(self.root,'add','.')
        plan=planner.make_plan(self.project,'Revisa un texto',files=['copy.txt'],scope='workspace',read_only=True)
        # Synthetic unit boundary: nested Bubblewrap is unavailable inside QA.
        # Only the probe is mocked; corrupt snapshot must stop before QA/dispatch.
        with patch('ipanema.orchestration.isolation.probe',return_value={'available':True,'mock':True}),patch.object(engine,'worker') as worker,patch.object(engine,'central_qa') as qa:
            result=engine.execute(self.project,plan,authorize=True)
            self.assertEqual(result['state'],'blocked');self.assertFalse(result['original_modified'])
            worker.assert_not_called();qa.assert_not_called()
        self.assertEqual(json.loads((Path(result['run'])/'run.json').read_text())['state'],'blocked')

    def test_invalid_non_markdown_source_records_blocked_before_qa(self):
        engine.git(self.root,'init','-q');(self.root/'copy.txt').write_bytes(b'\xff');engine.git(self.root,'add','.')
        plan=planner.make_plan(self.project,'Revisa un texto',files=['copy.txt'],scope='workspace',read_only=True)
        with patch('ipanema.orchestration.isolation.probe',return_value={'available':True,'mock':True}),patch.object(engine,'worker') as worker,patch.object(engine,'central_qa') as qa:
            result=engine.execute(self.project,plan,authorize=True)
            self.assertEqual(result['state'],'blocked');worker.assert_not_called();qa.assert_not_called()
        self.assertEqual(json.loads((Path(result['run'])/'run.json').read_text())['state'],'blocked')

    def test_qa_exception_records_blocked_and_never_dispatches(self):
        engine.git(self.root,'init','-q');engine.git(self.root,'add','.')
        plan=planner.make_plan(self.project,'Revisa un texto',files=['copy.txt'],scope='workspace',read_only=True)
        with patch('ipanema.orchestration.isolation.probe',return_value={'available':True,'mock':True}),patch.object(engine,'worker') as worker,patch.object(engine,'central_qa',side_effect=IpanemaError('Synthetic QA failure')):
            result=engine.execute(self.project,plan,authorize=True)
            self.assertEqual(result['state'],'blocked');worker.assert_not_called()
        self.assertIn('finished_at',json.loads((Path(result['run'])/'run.json').read_text()))

    def test_invalid_rules_utf8_is_project_error(self):
        (self.root/'AGENTS.md').write_bytes(b'\xff')
        with self.assertRaises(IpanemaError):engine.instruction_context(self.project,{'skills':[]})

    def test_central_qa_runs_both_suites_and_ignores_source_manifest(self):
        (self.root/'qa-snapshot-links.json').write_text('{"untrusted_source":true}')
        plan={'scope':'workspace','_controller_link_receipts':{'kind':'controller-offline-snapshot-links','scope':'identity_only_contents_excluded','links':[]}}
        with patch('ipanema.orchestration.isolation.run_isolated',return_value={'exit_code':0,'stderr':'Ran 1 test in 0.001s\nOK\n','mock':True}) as runner:
            result=engine.central_qa(self.project,plan,self.root,{})
        self.assertEqual([call.args[0][5] for call in runner.call_args_list],['tests/unit','tests/integration'])
        view=runner.call_args.args[2];manifest=json.loads((view/'qa-snapshot-links.json').read_text())
        self.assertNotIn('untrusted_source',manifest);self.assertEqual(manifest,plan['_controller_link_receipts']);self.assertTrue(result['passed'])

    def test_controller_manifest_cannot_be_declared_editable(self):
        (self.root/'qa-snapshot-links.json').write_text('{}')
        plan=planner.make_plan(self.project,'Revisa un texto',files=['qa-snapshot-links.json'],scope='workspace',read_only=True)
        with patch.object(engine,'config') as dispatch:
            with self.assertRaises(IpanemaError):engine.execute(self.project,plan,authorize=True)
            dispatch.assert_not_called()

    def test_private_configuration_never_supplies_controller_state(self):
        folder=self.root/'.local';folder.mkdir()
        for key in ['_adr','_supervisor','_council_budget','_controller_link_receipts']:
            (folder/'orchestration.json').write_text(json.dumps({key:{'synthetic':True}}))
            with self.subTest(key=key),self.assertRaises(IpanemaError):engine.config(self.project)

    def test_git_timeout_records_blocked_before_dispatch(self):
        import subprocess
        plan=planner.make_plan(self.project,'Revisa un texto',files=['copy.txt'],scope='workspace',read_only=True)
        with patch('ipanema.orchestration.isolation.probe',return_value={'available':True,'mock':True}),patch.object(engine,'prepare_snapshot',side_effect=subprocess.TimeoutExpired('synthetic git',1)),patch.object(engine,'worker') as worker:
            result=engine.execute(self.project,plan,authorize=True)
            self.assertEqual(result['state'],'blocked');worker.assert_not_called()
        self.assertIn('finished_at',json.loads((Path(result['run'])/'run.json').read_text()))

    def test_central_qa_rejects_empty_all_skipped_or_interrupted_results(self):
        cases=[{'stderr':'Ran 0 tests in 0.001s\nOK\n'}, {'stderr':'Ran 1 test in 0.001s\nOK (skipped=1)\n'}]
        cases += [{flag:True} for flag in ['timed_out','idle_timed_out','cancelled','output_limited']]
        cases += [{'process_reaped':False}]
        for index,case in enumerate(cases):
            fixture={'exit_code':0,'stderr':'Ran 1 test in 0.001s\nOK\n','mock':True,**case}
            with self.subTest(case=index),patch('ipanema.orchestration.isolation.run_isolated',return_value=fixture):
                result=engine.central_qa(self.project,{'scope':'workspace'},self.root,{})
                self.assertFalse(result['passed'])

class SnapshotLinkContract(unittest.TestCase):
    def setUp(self):
        from ipanema.snapshot_links import capture_omitted_links
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        root=Path(self.tmp.name);self.source=make_project(root/'source',theme=False);self.snapshot=make_project(root/'snapshot',theme=False)
        for r in [self.source,self.snapshot]:(r/'README.md').write_text('[History](reports/runs/old/report.json)\n')
        target=self.source/'reports/runs/old/report.json';target.parent.mkdir(parents=True);target.write_text('{"synthetic":true}')
        self.index=capture_omitted_links(self.source,self.snapshot);self.project=Project(self.snapshot)

    def receipt(self,name='reports/runs/old/report.json'):
        from ipanema.snapshot_links import omitted_link_receipt
        return omitted_link_receipt(self.project,self.snapshot/'README.md',self.snapshot/name,manifest=self.index)

    def test_receipt_is_identity_only_and_content_stays_excluded(self):
        self.assertEqual(len(self.index['links']),1);self.assertIsNotNone(self.receipt());self.assertFalse((self.snapshot/'reports/runs').exists());self.assertEqual(self.index['scope'],'identity_only_contents_excluded')

    def test_default_real_project_validation_remains_strict(self):
        from ipanema.snapshot_links import omitted_link_receipt
        self.project.data['environment']='offline-test'
        self.project.qa['snapshot_omissions']=self.index
        self.assertIsNone(omitted_link_receipt(self.project,self.snapshot/'README.md',self.snapshot/'reports/runs/old/report.json'))

    def test_changed_document_cannot_reuse_receipt(self):
        (self.snapshot/'README.md').write_text('Changed source [History](reports/runs/old/report.json)');self.assertIsNone(self.receipt())

    def test_new_private_unknown_and_forged_targets_rejected(self):
        for name in ['reports/runs/new/report.json','reports/runs/.env','projects/private.local.json','../outside.json']:
            with self.subTest(name=name):self.assertIsNone(self.receipt(name))
        self.index['links'][0]['destination_sha256']='not-a-hash';self.assertIsNone(self.receipt())

    def test_missing_or_symlinked_evidence_never_invented(self):
        from ipanema.snapshot_links import capture_omitted_links
        target=self.source/'reports/runs/old/report.json';target.unlink();self.assertEqual(capture_omitted_links(self.source,self.snapshot)['links'],[])
        target.symlink_to('/etc/hosts');self.assertEqual(capture_omitted_links(self.source,self.snapshot)['links'],[])

    def test_unindexed_receipt_never_matches(self):
        # Exercise full default validator on the real repository in its usual suite;
        # here this assertion checks the explicit exclusion predicate only.
        self.index={};self.assertIsNone(self.receipt())

    def test_full_validator_preserves_error_for_uninventoried_links(self):
        from ipanema.validation import validate
        from tests.support import put
        evidence=self.snapshot/'ipanema-discovery/13-evidence/measurements/source-baseline'
        for name,value in [('source-summary.json',{'settings':0}),('source-inventory.json',[]),('components.json',[]),('settings.json',[])]:put(evidence/name,value)
        (self.snapshot/'AGENTS.md').write_text('Fixture rules')
        approved=validate(self.project,snapshot_receipts=self.index)
        self.assertEqual(approved['errors'],[]);self.assertEqual(approved['snapshot_links_excluded'],1)
        self.assertTrue(any('Enlace roto' in e for e in validate(self.project)['errors']))
        self.project.data['environment']='offline-test'
        (self.snapshot/'README.md').write_text('[Unknown](reports/runs/new/report.json)')
        self.assertTrue(any('Enlace roto' in e for e in validate(self.project)['errors']))

    def test_strict_source_or_configured_theme_never_excludes(self):
        from ipanema.snapshot_links import omitted_link_receipt
        args=(self.project,self.snapshot/'README.md',self.snapshot/'reports/runs/old/report.json')
        self.assertIsNone(omitted_link_receipt(*args,manifest=self.index,strict_source=True))
        self.project.theme_root=self.snapshot/'theme'
        self.assertIsNone(omitted_link_receipt(*args,manifest=self.index))

    def test_malformed_manifest_fails_closed(self):
        self.index['links']=None;self.assertIsNone(self.receipt())

    def test_plain_receipt_never_certifies_lines_or_anchors(self):
        from ipanema.snapshot_links import capture_omitted_links
        from ipanema.validation import validate
        from tests.support import put
        text='[plain](reports/runs/old/report.json) [line](reports/runs/old/report.json:999999)\n[md](reports/runs/old/report.md) [anchor](reports/runs/old/report.md#missing)'
        for r in [self.source,self.snapshot]:(r/'README.md').write_text(text)
        put(self.source/'reports/runs/old/report.md','# Existing')
        evidence=self.snapshot/'ipanema-discovery/13-evidence/measurements/source-baseline'
        for name,value in [('source-summary.json',{'settings':0}),('source-inventory.json',[]),('components.json',[]),('settings.json',[])]:put(evidence/name,value)
        (self.snapshot/'AGENTS.md').write_text('Fixture')
        index=capture_omitted_links(self.source,self.snapshot)
        result=validate(self.project,snapshot_receipts=index)
        self.assertEqual(result['snapshot_links_excluded'],2);self.assertEqual(len(result['errors']),2)

    def validator_fixture(self):
        from tests.support import put
        evidence=self.snapshot/'ipanema-discovery/13-evidence/measurements/source-baseline'
        for name,value in [('source-summary.json',{'settings':0}),('source-inventory.json',[]),('components.json',[]),('settings.json',[])]:put(evidence/name,value)
        (self.snapshot/'AGENTS.md').write_text('Fixture')

    def test_catalog_identity_not_only_count_is_validated(self):
        import shutil
        from ipanema.validation import validate
        self.validator_fixture();(self.snapshot/'README.md').write_text('Fixture')
        real=self.snapshot/'.agents/skills/cloudflare-web-perf';renamed=real.with_name('ipanema-invented');real.rename(renamed)
        (renamed/'SKILL.md').write_text('---\nname: ipanema-invented\ndescription: fixture\n---')
        errors=validate(self.project)['errors']
        self.assertIn('Skill autorizada ausente: cloudflare-web-perf',errors);self.assertIn('Skill no registrada: ipanema-invented',errors)

    def test_relative_external_markdown_is_not_read(self):
        from ipanema.validation import validate
        self.validator_fixture();outside=self.snapshot.parent/'outside.md';outside.write_text('# Synthetic outside')
        (self.snapshot/'README.md').write_text('[Outside](../outside.md#synthetic)')
        original=Path.read_text
        def guarded(path,*args,**kwargs):
            if path.resolve()==outside:raise AssertionError('External document must not be read')
            return original(path,*args,**kwargs)
        with patch.object(Path,'read_text',guarded):result=validate(self.project)
        self.assertEqual(result['external_links_not_inspected'],1)

    def test_internal_link_symlinks_and_zero_line_are_rejected(self):
        from ipanema.validation import validate
        self.validator_fixture();real=self.snapshot/'real.md';real.write_text('# Real')
        link=self.snapshot/'alias.md';link.symlink_to(real)
        (self.snapshot/'README.md').write_text('[Symlink](alias.md#real) [Zero](real.md:0)')
        errors=validate(self.project)['errors'];self.assertEqual(len(errors),2)
