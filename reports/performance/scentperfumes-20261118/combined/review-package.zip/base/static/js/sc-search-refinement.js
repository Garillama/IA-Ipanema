/* Native search results/prices with bounded spelling recovery and relevance ranking. */
(function(){
 'use strict';
 const controllers=new Map(),cache=new Map();let sequence=0;
  // Public spelling hints from published product names/brands, 2026-10-23. Native results remain authoritative.
  const nameBrands={"aventus":"creed","santal 33":"le labo","tea storm":"louis vuitton","moon tale":"louis vuitton","ink mark":"louis vuitton","discovery set louis vuitton china collection":"scentperfumesmx","layton":"parfums de marly","king":"bharara","le male le parfum":"jean paul gaultier","invictus victory":"paco rabanne","noir extreme":"tom ford","ombre leather":"tom ford","spicebomb extreme":"viktor rolf","good girl":"carolina herrera","la vie est belle":"lancome","baccarat rouge 540 edp":"maison francis kurkdjian","delina":"parfums de marly","flowerbomb":"viktor rolf","angels share":"by kilian","sauvage parfum":"dior","le beau le parfum":"jean paul gaultier","by the fireplace":"maison margiela replica","naxos":"xerjoff","baccarat rouge 540 extrait de parfum":"maison francis kurkdjian","uomo born in roma":"valentino","le male elixir":"jean paul gaultier","millesime imperial":"creed","alexandria ii":"xerjoff","althair":"parfums de marly","sedley":"parfums de marly","costa azzura parfum":"tom ford","spicebomb dark leather":"viktor rolf","jazz club":"maison margiela replica","the most wanted edp":"azzaro","torino 21":"xerjoff","erba pura":"xerjoff","silver mountain water":"creed","coffee break":"maison margiela replica","l homme":"prada","paradoxe":"prada","l immensite":"louis vuitton","imagination":"louis vuitton","ombre nomade":"louis vuitton","meteore":"louis vuitton","sauvage edt":"dior","sauvage elixir":"dior","dior homme intense":"dior","eros eau de parfum":"versace","eros flame":"versace","eros energy":"versace","bright crystal":"versace","y edp":"ysl","black opium":"ysl","libre edp":"ysl","bleu de chanel edp":"chanel","allure homme sport eau extreme":"chanel","chance eau tendre edt":"chanel","coco mademoiselle":"chanel","stronger with you intensely":"emporio armani","acqua di gio parfum":"giorgio armani","light blue for her":"dolce gabbana","the one edp":"dolce gabbana","dylan blue":"versace","good girl blush":"carolina herrera","uomo born in roma intense":"valentino","cedrat boise edp":"mancera","discovery set louis vuitton":"scentperfumesmx","212 vip black":"carolina herrera","french riviera":"mancera","le male elixir absolu":"jean paul gaultier","symphony extrait de parfum":"louis vuitton","tobacco vanille":"tom ford","discovery set verano hombre":"scentperfumesmx","discovery set verano mujer":"scentperfumesmx","city of stars":"louis vuitton","discovery set back to school":"scentperfumesmx","discovery set back to office":"scentperfumesmx","afternoon swim":"louis vuitton","uomo born in roma extradose":"valentino","bleu de chanel l exclusif":"chanel","y le parfum":"ysl","bianco latte":"giardini di toscana","discovery set otono hombre":"scentperfumesmx","eragon":"parfums de marly","lazy sunday morning":"maison margiela replica","discovery set versace hombre":"scentperfumesmx","hawas":"rasasi","hawas ice":"rasasi","spicebomb infrared edp":"viktor rolf","spicebomb metallic musk":"viktor rolf","ambre levant":"louis vuitton","discovery set spicebomb":"scentperfumesmx","coro":"xerjoff","vibrato":"sospiro","instant crush":"mancera","discovery set primavera hombre":"scentperfumesmx","discovery set primavera mujer":"scentperfumesmx","uomo born in roma purple melancholia":"valentino","bleu de chanel parfum":"chanel","smoking hot":"by kilian","angels share on the rocks":"by kilian","discovery set cumplidos hombre":"scentperfumesmx","gentleman reserve privee":"givenchy","y edp 100 ml":"ysl","spicebomb extreme 90 ml":"viktor rolf","uomo born in roma intense 100 ml":"valentino","naxos 100 ml":"xerjoff","layton 125 ml":"parfums de marly","born in roma purple melancholia 100 ml":"valentino","hawas for him 100 ml":"rasasi","hawas ice 100 ml":"rasasi","by the fireplace 100 ml":"maison margiela replica","sauvage extrait":"dior","discovery set xerjoff":"scentperfumesmx","discovery set creed":"scentperfumesmx","discovery set valentino":"scentperfumesmx","discovery set tom ford":"scentperfumesmx","discovery set maison margiela replica":"scentperfumesmx","summer hammer":"lorenzo pazzaglia","chance eau fraiche edp":"chanel","mojave ghost":"byredo","carios":"parfums de marly","valero":"parfums de marly","iris debonair":"creed","spicebomb":"viktor rolf"};
  const vocabulary=["absolu","acqua","afternoon","alexandria","allure","althair","ambre","angels","armani","aventus","azzaro","azzura","baccarat","back","beau","belle","bharara","bianco","black","bleu","blue","blush","boise","born","break","bright","byredo","carios","carolina","cedrat","chance","chanel","china","city","club","coco","coffee","coro","costa","creed","crush","crystal","cumplidos","dark","debonair","delina","dior","dolce","dylan","elixir","emporio","energy","eragon","erba","eros","exclusif","extradose","extreme","fireplace","flame","flowerbomb","ford","fraiche","francis","french","gabbana","gaultier","gentleman","ghost","giardini","giorgio","girl","givenchy","good","hammer","hawas","herrera","hombre","imagination","immensite","imperial","infrared","instant","intensely","invictus","iris","jazz","jean","kilian","king","kurkdjian","labo","lancome","latte","layton","lazy","leather","levant","libre","light","lorenzo","louis","mademoiselle","maison","male","mancera","margiela","mark","marly","melancholia","metallic","meteore","millesime","mojave","moon","morning","most","mountain","mujer","musk","naxos","noir","nomade","office","ombre","opium","otono","paco","paradoxe","parfums","paul","pazzaglia","prada","primavera","privee","pura","purple","rabanne","rasasi","replica","reserve","riviera","rocks","rolf","roma","rouge","santal","sauvage","scentperfumesmx","school","sedley","share","silver","smoking","sospiro","spicebomb","sport","stars","storm","stronger","summer","sunday","swim","symphony","tale","tendre","tobacco","torino","toscana","uomo","valentino","valero","vanille","verano","versace","vibrato","victory","viktor","vuitton","wanted","water","xerjoff"];
  const aliases={"lelabo":"le labo","louisvuitton":"louis vuitton","parfumsdemarly":"parfums de marly","jeanpaulgaultier":"jean paul gaultier","pacorabanne":"paco rabanne","tomford":"tom ford","viktorrolf":"viktor rolf","carolinaherrera":"carolina herrera","maisonfranciskurkdjian":"maison francis kurkdjian","bykilian":"by kilian","maisonmargielareplica":"maison margiela replica","emporioarmani":"emporio armani","giorgioarmani":"giorgio armani","dolcegabbana":"dolce gabbana","giardiniditoscana":"giardini di toscana","lorenzopazzaglia":"lorenzo pazzaglia","yvessaintlaurent":"ysl","yves saint laurent":"ysl","saint laurent":"ysl","replica":"maison margiela","louis vitton":"louis vuitton","paco rabanne":"rabanne","paco":"rabanne","mfk":"maison francis kurkdjian","pdm":"parfums de marly"};
  function normalize(value){return value.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/([a-z])([0-9])/g,'$1 $2').replace(/([0-9])([a-z])/g,'$1 $2').replace(/[^a-z0-9\s]/g,' ').replace(/\s+/g,' ').trim();}
  function distance(a,b){
   const rows=Array.from({length:a.length+1},()=>Array(b.length+1).fill(0));
   for(let i=0;i<=a.length;i++)rows[i][0]=i;for(let j=0;j<=b.length;j++)rows[0][j]=j;
   for(let i=1;i<=a.length;i++)for(let j=1;j<=b.length;j++){
    rows[i][j]=Math.min(rows[i-1][j]+1,rows[i][j-1]+1,rows[i-1][j-1]+(a[i-1]===b[j-1]?0:1));
    if(i>1&&j>1&&a[i-1]===b[j-2]&&a[i-2]===b[j-1])rows[i][j]=Math.min(rows[i][j],rows[i-2][j-2]+1);
   }return rows[a.length][b.length];
  }
  function canonical(query){
   let q=normalize(query),compact=q.replace(/\s/g,''),alias=Object.hasOwn(aliases,q)?aliases[q]:Object.hasOwn(aliases,compact)?aliases[compact]:'';if(alias)return alias;
   if(compact.length>=3&&!Object.keys(nameBrands).some(name=>name.split(' ').some(word=>word.startsWith(compact)))){const completions=new Set(Object.keys(aliases).filter(key=>key.replace(/\s/g,'').startsWith(compact)).map(key=>aliases[key]));if(completions.size===1)return [...completions][0];}
   for(const phrase of Object.keys(aliases).filter(key=>key.includes(' ')).sort((a,b)=>b.length-a.length)){q=(' '+q+' ').split(' '+phrase+' ').join(' '+aliases[phrase]+' ').trim();}
   q=q.split(' ').map(word=>Object.hasOwn(aliases,word)?aliases[word]:word).join(' ');
   return q.split(' ').map(word=>{
    if(word.length<4||vocabulary.includes(word)||Object.keys(nameBrands).some(name=>name.split(' ').some(w=>w.startsWith(word))))return word;
    const limit=word.length>=8?2:1;let best=limit+1,candidates=[];
    vocabulary.forEach(candidate=>{if(Math.abs(candidate.length-word.length)>limit)return;const d=distance(word,candidate);if(d<best){best=d;candidates=[candidate];}else if(d===best)candidates.push(candidate);});
    return best<=limit&&candidates.length===1?candidates[0]:word;
   }).join(' ');
  }
  function rankResults(fragment,query){
   const items=[...fragment.querySelectorAll('.search-suggestions-item')];if(!items.length)return fragment;
   const q=normalize(query),tokens=q.split(' ').filter(Boolean),seen=new Set();
   let ranked=items.map((item,index)=>{
    const link=item.querySelector('a[href]'),name=normalize(item.querySelector('.search-suggestions-name')?.textContent||link?.textContent||''),brand=Object.hasOwn(nameBrands,name)?nameBrands[name]:'',words=name.split(' ');
    let score=0;if(name===q)score=10000;else if(name.replace(/\s/g,'')===q.replace(/\s/g,''))score=9800;
    else if(name.startsWith(q+' ')||name.startsWith(q))score=8000;
    else if(tokens.every(t=>words.some(w=>w===t||w.startsWith(t))))score=7000;
    else if(name.includes(q))score=6000;
    else if(tokens.every(t=>(name+' '+brand).split(' ').some(w=>w===t||w.startsWith(t))))score=5000;
    else score=tokens.reduce((n,t)=>n+(words.some(w=>w===t||w.startsWith(t))?300:0),0);
    return{item,index,score,key:link?.href};
   }).filter(x=>{if(!x.key||seen.has(x.key))return false;seen.add(x.key);return true;}).sort((a,b)=>b.score-a.score||a.index-b.index);
   ranked=ranked.slice(0,24);
   const list=items[0].parentElement;items.forEach(item=>item.remove());ranked.forEach(({item})=>list.append(item));return fragment;
  }

 function init(root){
  if(controllers.has(root))return;
  const form=root.querySelector('form'),input=form?.querySelector('input[name="q"]'),results=root.querySelector('[data-sc-search-results]'),status=root.querySelector('[data-sc-search-status]');
  if(!form||!input||!results||!status)return;
  const listeners=new AbortController(),opts={signal:listeners.signal};
  const clear=root.querySelector('.js-empty-search'),submit=root.querySelector('.js-search-input-submit'),host=root.closest('.sc-search');
  const storefrontOrigin=new URL(root.dataset.scStoreUrl||form.action,location.href).origin,previewId=new URL(location.href).searchParams.get('theme_installation_id');
  let timer,request=null,revision=0,composing=false,active=-1,links=[],disposed=false,resolved=null;
  results.id='sc-search-results-'+(++sequence);results.setAttribute('role','listbox');results.setAttribute('aria-label','Sugerencias de productos');
  input.setAttribute('role','combobox');input.setAttribute('aria-autocomplete','list');input.setAttribute('aria-controls',results.id);input.setAttribute('aria-expanded','false');
  function invalidate(){resolved=null;clearTimeout(timer);revision++;request?.abort();request=null;root.removeAttribute('aria-busy');}
  function announce(message){status.textContent=message;status.hidden=!message;}
  function resetActive(){active=-1;input.removeAttribute('aria-activedescendant');links.forEach(link=>link.setAttribute('aria-selected','false'));}
  function close(){invalidate();results.hidden=true;input.setAttribute('aria-expanded','false');resetActive();announce('');}
  function buttons(){const filled=!!input.value;if(clear){clear.style.display='';clear.hidden=!filled;}if(submit){submit.style.display='';submit.hidden=false;}}
  function viewport(){root.style.setProperty('--sc-search-viewport',(window.visualViewport?.height||innerHeight)+'px');}
  function safeHTML(html){
   const template=document.createElement('template');template.innerHTML=html;
   template.content.querySelectorAll('script,style,iframe,object,embed,link,meta,base,form,input,button').forEach(node=>node.remove());
   template.content.querySelectorAll('*').forEach(node=>{for(const attribute of [...node.attributes]){
    const name=attribute.name.toLowerCase();
    if(name.startsWith('on')||name==='srcdoc'||name==='autofocus')node.removeAttribute(attribute.name);
    if(['href','src','xlink:href'].includes(name)){
     try{
      const url=new URL(attribute.value,location.href);
      if(!['https:','http:'].includes(url.protocol)){node.removeAttribute(attribute.name);continue;}
      if(name==='href'&&url.origin!==location.origin){
       if(url.origin!==storefrontOrigin){node.removeAttribute(attribute.name);continue;}
       const local=new URL(url.pathname+url.search+url.hash,location.origin);
       if(previewId)local.searchParams.set('theme_installation_id',previewId);
       node.setAttribute(attribute.name,local.href);
      }
     }catch{node.removeAttribute(attribute.name);}
    }
   }});return template.content;
  }
  function fullURL(query){let url=new URL(form.action,location.href);if(url.origin!==location.origin)url=new URL(url.pathname+url.search,location.origin);if(previewId)url.searchParams.set('theme_installation_id',previewId);url.searchParams.set('q',query);return url;}
  function render(html,count,query,originalQuery=query){
   resolved=count>0?{input:originalQuery,term:query}:null;
   results.replaceChildren(rankResults(safeHTML(html),query));
   if(count&&normalize(originalQuery)!==normalize(query)){const note=document.createElement('p');note.className='sc-search-correction';note.textContent='Coincidencias para “'+query+'”.';results.prepend(note);}
   if(count){const heading=document.createElement('div');heading.className='sc-search-count';heading.textContent=count+(count===1?' resultado':' resultados');results.prepend(heading);}
   if(!count||!results.querySelector('a[href]')){
    const message=document.createElement('p');message.className='sc-search-empty';message.textContent='No encontramos sugerencias para “'+query+'”. Puedes ver la búsqueda completa.';results.replaceChildren(message);
   }
   // Native response uses a DIV for this control; replace it with a real keyboard-operable link.
   results.querySelectorAll('.search-suggestions-all-link-container,.js-search-suggestions-all-link,.search-suggestions-all-link').forEach(node=>node.remove());
   if(!results.querySelector('.js-search-suggestions-all-link,.search-suggestions-all-link')){
    const row=document.createElement('div'),link=document.createElement('a');row.className='search-suggestions-all-link-container';link.className='js-search-suggestions-all-link search-suggestions-all-link';link.href=fullURL(query).href;link.textContent='Ver todos los resultados';const icon=document.createElementNS('http://www.w3.org/2000/svg','svg'),path=document.createElementNS('http://www.w3.org/2000/svg','path');icon.setAttribute('width','14');icon.setAttribute('height','14');icon.setAttribute('viewBox','0 0 24 24');icon.setAttribute('aria-hidden','true');path.setAttribute('d','M5 12h14m-5-5 5 5-5 5');path.setAttribute('fill','none');path.setAttribute('stroke','currentColor');path.setAttribute('stroke-width','1.5');path.setAttribute('stroke-linecap','round');path.setAttribute('stroke-linejoin','round');icon.append(path);link.append(icon);row.append(link);results.append(row);
   }
   results.querySelectorAll('.js-search-suggestions-all-link,.search-suggestions-all-link').forEach(link=>link.href=fullURL(query).href);
   links=[...results.querySelectorAll('a[href]')];links.forEach((link,index)=>{link.id=results.id+'-option-'+index;link.setAttribute('role','option');link.setAttribute('aria-selected','false');});
   active=-1;input.removeAttribute('aria-activedescendant');results.hidden=false;input.setAttribute('aria-expanded','true');const shown=results.querySelectorAll('.search-suggestions-item').length||Math.min(6,count);announce(count?shown+(shown===1?' sugerencia disponible.':' sugerencias disponibles.'):'Sin sugerencias.');
  }
  async function search(query,ticket){
   request=new AbortController();const current=request;let timedOut=false;
   const timeout=setTimeout(()=>{timedOut=true;current.abort();},6000);
   root.setAttribute('aria-busy','true');announce('Buscando…');
   async function retrieve(term){
    const cached=cache.get(term);if(cached&&Date.now()-cached.time<(Number(cached.data.count)>0?120000:10000))return cached.data;
    const url=new URL('/search/',location.origin);url.searchParams.set('q',term);url.searchParams.set('limit','24');
    const response=await fetch(url.href,{credentials:'same-origin',headers:{'X-Requested-With':'XMLHttpRequest','Accept':'image/webp'},signal:current.signal});
    if(!response.ok)throw new Error('Search unavailable');const data=await response.json();
    if(typeof data.html!=='string'||!Number.isFinite(Number(data.count)))throw new Error('Unexpected search response');
    if(current.signal.aborted)throw new DOMException('Aborted','AbortError');
    if(cache.size>=32)cache.delete(cache.keys().next().value);cache.set(term,{time:Date.now(),data});return data;
   }
   try{
    let term=query.trim(),data=await retrieve(term);
    // Search the current catalog before trying hints built from older product names.
    if(!Number(data.count)){
     const corrected=canonical(term);
     if(corrected&&normalize(corrected)!==normalize(term)){term=corrected;data=await retrieve(term);}
    }
    if(disposed||ticket!==revision||input.value.trim()!==query||current.signal.aborted)return;
    render(data.html,Math.max(0,Number(data.count)),term,query);
   }catch(error){
    if(disposed||ticket!==revision||(error.name==='AbortError'&&!timedOut))return;
    results.hidden=true;input.setAttribute('aria-expanded','false');announce('No pudimos cargar las sugerencias. Pulsa Buscar para ver los resultados.');
   }finally{clearTimeout(timeout);if(ticket===revision){root.removeAttribute('aria-busy');request=null;}}
  }
  function schedule(){
   if(host?.hidden){close();buttons();return;}
   invalidate();buttons();results.hidden=true;input.setAttribute('aria-expanded','false');resetActive();
   const query=input.value.trim();if(composing||!query.length){announce('');return;}
   const ticket=revision;timer=setTimeout(()=>search(query,ticket),250);
  }
  input.addEventListener('input',schedule,opts);
  input.addEventListener('focus',()=>{if(input.value.trim()&&results.hidden)schedule();},opts);
  input.addEventListener('compositionstart',()=>{composing=true;root.setAttribute('data-sc-search-composing','');close();},opts);
  input.addEventListener('compositionend',()=>{composing=false;root.removeAttribute('data-sc-search-composing');schedule();},opts);
  input.addEventListener('keydown',event=>{
   if(event.isComposing||composing)return;
   if(event.key==='Escape'){event.preventDefault();event.stopPropagation();close();host?.dispatchEvent(new CustomEvent('sc:search-close',{bubbles:true,detail:{restoreFocus:true}}));return;}
   if(results.hidden||!links.length)return;
   if(event.key==='ArrowDown'||event.key==='ArrowUp'){
    event.preventDefault();active=active<0?(event.key==='ArrowDown'?0:links.length-1):(active+(event.key==='ArrowDown'?1:-1)+links.length)%links.length;
    links.forEach((link,index)=>link.setAttribute('aria-selected',String(index===active)));input.setAttribute('aria-activedescendant',links[active].id);links[active].scrollIntoView({block:'nearest',behavior:'instant'});
   }else if(event.key==='Enter'&&active>=0){event.preventDefault();links[active].click();}
  },opts);
  /* Keep the input/keyboard stable until the tap completes; blurring can move the hit target. */
  clear?.addEventListener('pointerdown',event=>event.preventDefault(),opts);
  results.addEventListener('pointerdown',event=>{if(event.target.closest('a[href]'))event.preventDefault();},opts);
  clear?.addEventListener('click',event=>{event.preventDefault();input.value='';close();buttons();input.focus({preventScroll:true});},opts);
  form.addEventListener('submit',()=>{if(resolved&&input.value.trim()===resolved.input)input.value=resolved.term;close();},opts);
  root.addEventListener('focusout',()=>queueMicrotask(()=>{if(!root.contains(document.activeElement))close();}),opts);
  document.addEventListener('pointerdown',event=>{if(!root.contains(event.target))close();},opts);
  window.visualViewport?.addEventListener('resize',viewport,opts);window.addEventListener('resize',viewport,opts);
  const hiddenObserver=host?new MutationObserver(()=>{if(host.hidden){composing=false;root.removeAttribute('data-sc-search-composing');close();}}):null;hiddenObserver?.observe(host,{attributes:true,attributeFilter:['hidden']});
  function cleanup(){disposed=true;root.removeAttribute('data-sc-search-composing');close();listeners.abort();hiddenObserver?.disconnect();controllers.delete(root);}
  controllers.set(root,cleanup);buttons();viewport();
 }
 function scan(){controllers.forEach((cleanup,root)=>{if(!root.isConnected)cleanup();});document.querySelectorAll('[data-sc-search-refinement]').forEach(init);}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',scan,{once:true});else scan();
 new MutationObserver(scan).observe(document.documentElement,{childList:true,subtree:true});
 document.addEventListener('nube:section:unload',event=>{controllers.forEach((cleanup,root)=>{if(event.target===root||event.target.contains?.(root))cleanup();});});
})();
