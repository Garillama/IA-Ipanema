/* SCENT global navigation: one content tree, responsive placement, idempotent editor init. */
(function () {
 'use strict';
 const desktop = window.matchMedia('(min-width:1024px)');
 const reduced = window.matchMedia('(prefers-reduced-motion:reduce)');
 const controllers = new Map();
 const easing = 'cubic-bezier(.22,1,.36,1)';
 function init(root) {
  if (controllers.has(root)) return;
  const nav = root.querySelector('.sc-header-nav'), open = root.querySelector('[data-sc-menu-open]');
  if (!nav || !open) return;
  root.dataset.scReady = 'true';
  const abort = new AbortController(), opts = {signal:abort.signal};
  const panels = [...root.querySelectorAll('[data-sc-panel]')], triggers = [...root.querySelectorAll('[data-sc-menu-trigger]')];
  const mobileTriggers = [...root.querySelectorAll('[data-sc-mobile-menu-trigger]')];
  const scrim = root.querySelector('.sc-menu-scrim'), search = root.querySelector('.sc-search'), searchToggle = root.querySelector('[data-sc-search-toggle]');
  const background = new Map(), animations = new Set();
  let last = null, originalOverflow = '', locked = false, timer, navAnimation = null, revision = 0, closing = false, returnFocus = true, principalScroll = 0, lastFocusTarget = document.activeElement;
  function hideBackground(on) {
   if (on) {
    for (let branch = nav; branch.parentElement; branch = branch.parentElement) {
     const parent = branch.parentElement;
     for (const node of parent.children) {
      if (node === branch || node.matches('script,style,link')) continue;
      if (!background.has(node)) background.set(node,node.inert);
      node.inert = true;
     }
     if (parent === document.body) break;
    }
   }
   if (!on) { background.forEach((value,node) => node.inert = value); background.clear(); }
  }
  function semantics(isOpen) {
   if (desktop.matches) { nav.removeAttribute('role'); nav.removeAttribute('aria-modal'); nav.removeAttribute('aria-hidden'); nav.inert = false; }
   else { nav.setAttribute('role','dialog'); nav.setAttribute('aria-modal','true'); nav.setAttribute('aria-hidden',String(!isOpen)); nav.inert = !isOpen; }
   hideBackground(isOpen && !desktop.matches);
  }
  function lock(on) {
   if (on && !desktop.matches && !locked) { originalOverflow = document.body.style.overflow; document.body.style.overflow = 'hidden'; locked = true; }
   else if (!on && locked) { document.body.style.overflow = originalOverflow; locked = false; }
  }
  function animate(node,frames,duration) {
   if (!node || reduced.matches || !node.animate) return null;
   const animation = node.animate(frames,{duration,easing}); animations.add(animation);
   animation.finished.then(() => animations.delete(animation),() => animations.delete(animation));
   return animation;
  }
  function cancelNav() { revision++; if (navAnimation) navAnimation.cancel(); navAnimation = null; }
  function cancelContent() { animations.forEach(animation => { if (animation !== navAnimation) animation.cancel(); }); }
  function clearPanels() {
   panels.forEach(panel => panel.hidden = true);
   [...triggers,...mobileTriggers].forEach(trigger => trigger.setAttribute('aria-expanded','false'));
   nav.classList.remove('sc-mobile-panel-open'); if (scrim) scrim.hidden = true;
  }
  function finishClose(restore) {
   cancelNav(); cancelContent(); closing = false; nav.removeAttribute('data-sc-closing');
   clearPanels(); nav.classList.remove('is-open'); open.setAttribute('aria-expanded','false');
   lock(false); semantics(false);
   if (restore && root.isConnected) (desktop.matches ? last : open)?.focus({preventScroll:true});
  }
  function close(restore = true, immediate = false) {
   clearTimeout(timer); returnFocus = restore;
   if (immediate || (!desktop.matches && !nav.classList.contains('is-open')) || reduced.matches) { finishClose(restore); return; }
   if (closing) return;
   const surface = desktop.matches ? panels.find(panel => !panel.hidden) : nav;
   const computed = surface && getComputedStyle(surface);
   const start = computed && {opacity:computed.opacity,transform:computed.transform};
   cancelNav(); cancelContent(); closing = true; nav.setAttribute('data-sc-closing',''); open.setAttribute('aria-expanded','false');
   const ticket = revision;
   navAnimation = start && animate(surface,[start,{opacity:0,transform:desktop.matches ? 'translateY(-8px)' : 'translateX(-24px)'}],desktop.matches ? 360 : 420);
   if (desktop.matches && scrim && !scrim.hidden) animate(scrim,[{opacity:1},{opacity:0}],360);
   if (!navAnimation) finishClose(restore);
   else navAnimation.finished.then(() => { if (ticket === revision) finishClose(returnFocus); },() => {});
  }
  function closeSearch(restore = false) {
   if (!search || search.hidden) return;
   const hadFocus = search.contains(document.activeElement);
   search.hidden = true; searchToggle?.setAttribute('aria-expanded','false');
   if (restore) searchToggle?.focus({preventScroll:true});
   else if (hadFocus) document.activeElement?.blur();
  }
  function isSearchComposing() { return !!search?.querySelector('[data-sc-search-composing]'); }
  function showMenu() {
   closeSearch();
   if (nav.classList.contains('is-open') && !closing) return;
   const previous = nav.classList.contains('is-open') ? {opacity:getComputedStyle(nav).opacity,transform:getComputedStyle(nav).transform} : {opacity:0,transform:'translateX(-32px)'};
   cancelNav(); cancelContent(); closing = false; nav.removeAttribute('data-sc-closing'); last = open;
   nav.classList.add('is-open'); open.setAttribute('aria-expanded','true'); lock(true); semantics(true); nav.scrollTop = 0;
   navAnimation = animate(nav,[previous,{opacity:1,transform:'translateX(0)'}],560);
   nav.querySelector('.sc-principal-only')?.focus({preventScroll:true});
  }
  function panel(id,from) {
   closeSearch();
   const target = panels.find(panel => panel.dataset.scPanel === id); if (!target) return;
   if (desktop.matches && !target.hidden && !closing) return;
   const previousPanel = desktop.matches && !target.hidden ? {opacity:getComputedStyle(target).opacity,transform:getComputedStyle(target).transform} : {opacity:0,transform:'translateY(-12px)'};
   if (!desktop.matches && !nav.classList.contains('sc-mobile-panel-open')) principalScroll = nav.scrollTop;
   cancelNav(); cancelContent(); closing = false; nav.removeAttribute('data-sc-closing'); clearPanels(); target.hidden = false;
   const desktopTrigger = triggers.find(trigger => trigger.dataset.scMenuTrigger === id);
   desktopTrigger?.setAttribute('aria-expanded','true');
   mobileTriggers.filter(trigger => trigger.dataset.scMobileMenuTrigger === desktopTrigger?.dataset.scMenuKey).forEach(trigger => trigger.setAttribute('aria-expanded','true'));
   nav.classList.add('sc-mobile-panel-open');
   if (desktop.matches) {
    root.style.setProperty('--sc-header-bottom',root.getBoundingClientRect().bottom+'px');
    if (scrim) { const wasHidden = scrim.hidden; scrim.hidden = false; if (wasHidden) animate(scrim,[{opacity:0},{opacity:1}],520); }
    animate(target,[previousPanel,{opacity:1,transform:'translateY(0)'}],560);
   }
   else {
    nav.classList.add('is-open'); open.setAttribute('aria-expanded','true'); lock(true); semantics(true); nav.scrollTop = 0;
    animate(target,[{opacity:0,transform:'translateX(24px)'},{opacity:1,transform:'translateX(0)'}],480);
   }
   if (from) last = from;
  }
  open.addEventListener('click',showMenu,opts);
  mobileTriggers.forEach(trigger => trigger.addEventListener('click',() => {
   const desktopTrigger = triggers.find(item => item.dataset.scMenuKey === trigger.dataset.scMobileMenuTrigger);
   if (desktopTrigger) { panel(desktopTrigger.dataset.scMenuTrigger,trigger); nav.querySelector('[data-sc-menu-back]')?.focus({preventScroll:true}); }
  },opts));
  triggers.forEach(trigger => {
   trigger.addEventListener('click',() => trigger.getAttribute('aria-expanded') === 'true' ? close() : panel(trigger.dataset.scMenuTrigger,trigger),opts);
   trigger.addEventListener('pointerenter',event => { if (desktop.matches && event.pointerType !== 'touch') { clearTimeout(timer); timer = setTimeout(() => panel(trigger.dataset.scMenuTrigger,trigger),140); } },opts);
  });
  root.querySelectorAll('[data-sc-menu-close]').forEach(button => button.addEventListener('click',() => close(),opts));
  root.querySelector('[data-sc-menu-back]')?.addEventListener('click',() => {
   cancelContent(); clearPanels(); nav.scrollTop = principalScroll;
   const home = nav.querySelector('[data-sc-mobile-menu-home]');
   animate(home,[{opacity:0,transform:'translateX(-24px)'},{opacity:1,transform:'translateX(0)'}],440);
   (last?.getClientRects().length ? last : nav.querySelector('.sc-principal-only'))?.focus({preventScroll:true});
  },opts);
  root.addEventListener('pointerleave',() => { if (desktop.matches) timer = setTimeout(() => close(false),260); },opts);
  root.addEventListener('pointerenter',() => clearTimeout(timer),opts);
  let searchScrollStart = window.scrollY;
  searchToggle?.addEventListener('click',() => {
   if (!search) return;
   if (!search.hidden) { closeSearch(true); return; }
   close(false,true); search.hidden = false; searchToggle.setAttribute('aria-expanded','true'); searchScrollStart = window.scrollY;
   search.querySelector('input')?.focus({preventScroll:true});
  },opts);
  root.addEventListener('sc:search-close',event => closeSearch(!!event.detail?.restoreFocus),opts);
  document.addEventListener('pointerdown',event => { if (search && !search.hidden && !search?.contains(event.target) && !searchToggle?.contains(event.target)) closeSearch(); },{...opts,capture:true});
  document.addEventListener('wheel',event => { if (search && !search.hidden && !isSearchComposing() && Math.abs(event.deltaY)>4 && !search?.contains(event.target)) closeSearch(); },{...opts,passive:true});
  window.addEventListener('scroll',() => { if (search && !search.hidden && !isSearchComposing() && !search?.contains(document.activeElement) && Math.abs(window.scrollY-searchScrollStart)>24) closeSearch(); },{...opts,passive:true});
  document.addEventListener('keydown',event => { if (event.key==='Escape' && !event.defaultPrevented && search && !search.hidden) { event.preventDefault(); closeSearch(true); } },opts);
  root.addEventListener('keydown',event => {
   if (event.key === 'Escape') { close(); closeSearch(true); }
   if (event.key === 'Tab' && !desktop.matches && nav.classList.contains('is-open')) {
    const items = [...nav.querySelectorAll('button,a[href],input')].filter(node => node.getClientRects().length && !node.disabled && !node.closest('[inert]'));
    const first = items[0], lastItem = items.at(-1);
    if (!first || closing) { event.preventDefault(); return; }
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); lastItem.focus(); }
    else if (!event.shiftKey && document.activeElement === lastItem) { event.preventDefault(); first.focus(); }
   }
  },opts);
  document.addEventListener('focusin',event => { lastFocusTarget = event.target; if (search && !search.hidden && !search?.contains(event.target) && !searchToggle?.contains(event.target)) closeSearch(); if (desktop.matches && panels.some(panel => !panel.hidden) && !nav.contains(event.target)) close(false); },opts);
  desktop.addEventListener('change',() => {
   const focusWasInNav = nav.contains(document.activeElement) || (document.activeElement === document.body && nav.contains(lastFocusTarget));
   const activeTrigger = triggers.find(trigger => trigger.getAttribute('aria-expanded') === 'true');
   close(false,true);
   if (focusWasInNav && root.isConnected) (desktop.matches ? (activeTrigger || triggers[0] || root.querySelector('.sc-header-logo')) : open)?.focus({preventScroll:true});
  },opts);
  reduced.addEventListener('change',() => { if (reduced.matches) { if (closing) finishClose(returnFocus); else { cancelNav(); cancelContent(); } } },opts);
  semantics(false);
  function cleanup() { closeSearch(); abort.abort(); clearTimeout(timer); finishClose(false); delete root.dataset.scReady; controllers.delete(root); }
  root._scCleanup = cleanup; controllers.set(root,cleanup);
 }
 function scan() {
  controllers.forEach((cleanup,root) => { if (!root.isConnected) cleanup(); });
  document.querySelectorAll('[data-sc-header]').forEach(init);
 }
 if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded',scan,{once:true}); else scan();
 new MutationObserver(records=>{
  const detached=[...controllers.keys()].some(root=>!root.isConnected);
  const pending=records.some(({target})=>{const root=target.nodeType===1&&target.closest('[data-sc-header]');return root&&!controllers.has(root);});
  const relevant=records.some(record=>[...record.addedNodes,...record.removedNodes].some(node=>node.nodeType===1&&(node.matches('[data-sc-header]')||node.querySelector('[data-sc-header]'))));
  if(detached||pending||relevant)scan();
 }).observe(document.documentElement,{childList:true,subtree:true});
 document.addEventListener('nube:section:unload',event => { if (event.target.matches?.('[data-sc-header]')) event.target._scCleanup?.(); event.target.querySelectorAll?.('[data-sc-header]').forEach(root => root._scCleanup?.()); });
})();

/* Accessibility for native LS modals and the native AJAX add confirmation. */
(function(){'use strict';let active=null,returnTo=null;const originalInert=new Map();let savedOverflow='';
function eligible(){return [...document.querySelectorAll('.js-modal-private.modal-visible,.sc-cart-confirmation.notification-visible')].filter(n=>n.getClientRects().length).at(-1)}
function focusables(n){return [...n.querySelectorAll('a[href],button,input,select,textarea,[tabindex="0"]')].filter(x=>!x.disabled&&x.getClientRects().length)}
function restore(){originalInert.forEach((value,node)=>node.inert=value);originalInert.clear();document.body.style.overflow=savedOverflow}
function update(){const next=eligible();if(next===active)return;if(active){restore();if(!active.matches('.sc-collection-sheet')&&returnTo?.isConnected)returnTo.focus()}active=next;if(!next)return;next.inert=false;returnTo=document.activeElement;savedOverflow=document.body.style.overflow;document.body.style.overflow='hidden';next.setAttribute('role','dialog');next.setAttribute('aria-modal','true');if(!next.hasAttribute('tabindex'))next.tabIndex=-1;const title=next.querySelector('.modal-title,.sc-cart-confirmation-title');if(title)next.setAttribute('aria-label',title.textContent.trim());/* A sheet may live inside MainContent: inert siblings along its ancestor path, never its ancestor. */
for(let branch=next;branch.parentElement;branch=branch.parentElement){const parent=branch.parentElement;for(const node of parent.children){if(node===branch||node.matches('script,style,link'))continue;const ownOverlay=node.matches('.js-modal-overlay-private')&&(node.dataset.target==='#'+next.id||node.dataset.overlayId==='#'+next.id);const ownScrim=node.matches('.sc-confirmation-scrim')&&next.matches('.sc-cart-confirmation');if(ownOverlay||ownScrim)continue;if(!originalInert.has(node))originalInert.set(node,node.inert);node.inert=true}if(parent===document.body)break}if(!next.matches('.sc-collection-sheet'))(focusables(next)[0]||next).focus()}
function close(){active?.querySelector('.js-modal-close-private,.js-cart-notification-close-private')?.click()}
document.addEventListener('keydown',e=>{if(e.defaultPrevented||!active||active.matches('.sc-collection-sheet'))return;if(e.key==='Escape'){e.preventDefault();close()}if(e.key==='Tab'){const items=focusables(active),first=items[0],last=items.at(-1);if(!first){e.preventDefault();active.focus()}else if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}}});
function init(){const confirmation=document.querySelector('.sc-cart-confirmation');if(confirmation){const scrim=document.createElement('button');scrim.type='button';scrim.className='sc-confirmation-scrim';scrim.hidden=true;scrim.tabIndex=-1;scrim.setAttribute('aria-label',confirmation.querySelector('.notification-close')?.getAttribute('aria-label')||'Cerrar');scrim.addEventListener('click',()=>confirmation.querySelector('.notification-close')?.click());document.body.appendChild(scrim);new MutationObserver(()=>{scrim.hidden=!confirmation.classList.contains('notification-visible');update()}).observe(confirmation,{attributes:true,attributeFilter:['class','style']});confirmation.classList.add('sc-cart-confirmation--scrim')}
const watched=new WeakSet();function bind(){document.querySelectorAll('.js-modal-private').forEach(n=>{if(watched.has(n))return;watched.add(n);new MutationObserver(update).observe(n,{attributes:true,attributeFilter:['class','style']})})}bind();let queued=false;new MutationObserver(()=>{if(queued)return;queued=true;queueMicrotask(()=>{queued=false;bind();update()})}).observe(document.body,{childList:true,subtree:true});update()}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();

/* The editorial goal never overrides LS shipping eligibility or rates. */
(function(){
 'use strict';
 function initShippingGoal(){
  var cart=document.getElementById('modal-cart');if(!cart)return;
  var queued=false;
  function raw(selector,fallback){var node=document.querySelector(selector);var val=node&&node.getAttribute('data-priceraw');return val!==null&&val!==''&&Number.isFinite(Number(val))?Number(val):Number(fallback)||0;}
  function render(){queued=false;var goal=cart.querySelector('[data-sc-shipping-goal]');if(!goal)return;
   var target=Number(goal.dataset.scShippingGoal);var hasItems=!!cart.querySelector('.js-cart-item-shippable');
   var nativeBar=cart.querySelector('.js-ship-free-rest');
   var nativeAvailable=nativeBar&&getComputedStyle(nativeBar).display!=='none';
   goal.hidden=!hasItems||!(target>0)||!!nativeAvailable;if(goal.hidden)return;
   var subtotal=raw('.js-cart-subtotal[data-priceraw]',goal.dataset.scInitialSubtotal);
   var discount=raw('.js-cart-discount[data-priceraw]',goal.dataset.scInitialDiscount);
   var value=Math.max(0,subtotal-discount),left=Math.max(0,target-value),ratio=Math.min(1,value/target);
   var message=goal.querySelector('[data-sc-goal-message]');
   var formatted=new Intl.NumberFormat('es-MX',{style:'currency',currency:'MXN',maximumFractionDigits:0}).format(Math.ceil(left/100));
   var copy=left>0?'Te faltan '+formatted+' para envío gratis':'¡Llegaste a la meta de '+new Intl.NumberFormat('es-MX',{style:'currency',currency:'MXN',maximumFractionDigits:0}).format(target/100)+'!';
   if(message.textContent!==copy)message.textContent=copy;
   var track=goal.querySelector('[data-sc-goal-track]'),percent=String(Math.round(ratio*100));
   if(track.getAttribute('aria-valuenow')!==percent)track.setAttribute('aria-valuenow',percent);
   goal.querySelector('[data-sc-goal-fill]').style.transform='scaleX('+ratio+')';
  }
  function schedule(){if(queued)return;queued=true;requestAnimationFrame(render);}
  document.addEventListener('cart.updated',schedule);
  new MutationObserver(function(records){if(records.some(function(r){return r.type==='childList'&&(r.target.closest('.js-ajax-cart-list')||r.target===cart)||r.type==='attributes'&&r.target.matches('.js-cart-subtotal,.js-cart-discount,.js-ship-free-rest');}))schedule();}).observe(document.body,{subtree:true,childList:true,attributes:true,attributeFilter:['data-priceraw','style','class']});
  render();
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initShippingGoal,{once:true});else initShippingGoal();
})();

/* Barra de escalones por cantidad (Buen Fin): cuenta decants del carrito (excluye Discovery Sets) y muestra
   cuánto falta para 10/15/20 %. Solo informa: el descuento lo aplica la promoción nativa de TN. Se oculta
   si ningún decant trae etiqueta de promoción por cantidad (promo apagada) o si el carrito está vacío. */
(function(){
 'use strict';
 function initTierGoal(){
  var cart=document.getElementById('modal-cart');if(!cart)return;
  var queued=false,mobile=window.matchMedia('(max-width:767px)');
  /* Festejo al alcanzar un escalón (12-nov-2026): pulso en el punto, destello en la tarjeta y confeti breve.
     Solo cuando el escalón SUBE durante la visita (no al cargar la página). Si el cajón está cerrado, espera a que se vea. */
  var lastQ=null,pendingQ=0,seen=null,calm=window.matchMedia('(prefers-reduced-motion: reduce)');
  function play(goal,q){
   var mark=goal.querySelector('[data-sc-tier-mark="'+q+'"]'),step=goal.querySelector('[data-sc-tier-step="'+q+'"]');
   goal.classList.remove('is-celebrating');void goal.offsetWidth;goal.classList.add('is-celebrating');
   if(mark){mark.classList.remove('is-pop');void mark.offsetWidth;mark.classList.add('is-pop');}
   if(step){step.classList.remove('is-pop');void step.offsetWidth;step.classList.add('is-pop');}
   if(mark&&!calm.matches){
    var g=goal.getBoundingClientRect(),m=mark.getBoundingClientRect(),x=m.left+m.width/2-g.left,y=m.top+m.height/2-g.top;
    var colors=['#33483e','#c9a24b','#8fa89a','#e0ddd8','#33483e','#c9a24b'];
    for(var i=0;i<12;i++){var c=document.createElement('span');c.className='sc-tier-confetti';c.setAttribute('aria-hidden','true');
     var ang=(-Math.PI/2)+(i-5.5)*(Math.PI/9),dist=26+((i*37)%20);
     c.style.left=x+'px';c.style.top=y+'px';c.style.background=colors[i%colors.length];
     c.style.setProperty('--dx',Math.round(Math.cos(ang)*dist)+'px');c.style.setProperty('--dy',Math.round(Math.sin(ang)*dist)+'px');c.style.setProperty('--r',((i%2?1:-1)*(120+i*20))+'deg');
     c.style.animationDelay=(i%4*30)+'ms';goal.appendChild(c);
     (function(n){setTimeout(function(){if(n.parentNode)n.parentNode.removeChild(n);},1300);})(c);}
   }
   setTimeout(function(){goal.classList.remove('is-celebrating');if(mark)mark.classList.remove('is-pop');if(step)step.classList.remove('is-pop');},1500);
  }
  function celebrate(goal,q){
   var r=goal.getBoundingClientRect(),visible=r.width>0&&r.height>0&&r.bottom>0&&r.top<window.innerHeight&&r.right>0&&r.left<window.innerWidth;
   if(visible){pendingQ=0;play(goal,q);return;}
   pendingQ=q;
   if(!seen&&'IntersectionObserver' in window){seen=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting&&pendingQ){var q2=pendingQ;pendingQ=0;setTimeout(function(){play(e.target,q2);},350);}});},{threshold:.6});seen.observe(goal);}
  }
  function render(){queued=false;var goal=cart.querySelector('[data-sc-tier-goal]');if(!goal)return;
   var tiers=(goal.dataset.scTiers||'').split(',').map(function(t){var p=t.split(':');return {q:parseInt(p[0],10),pct:parseInt(p[1],10)};}).filter(function(t){return t.q>0&&t.pct>0;}).sort(function(a,b){return a.q-b.q;});
   if(!tiers.length){goal.hidden=true;return;}
   var excl=(goal.dataset.scExclude||'').toLowerCase();
   var count=0,sets=0,promo=false;
   cart.querySelectorAll('.js-cart-item').forEach(function(it){
    if(it.getAttribute('data-gift')==='true')return;
    var nameEl=it.querySelector('.cart-item-name');var name=nameEl?nameEl.textContent.toLowerCase():'';
    var inp=it.querySelector('.js-cart-quantity-input');var q=inp?parseInt(inp.value,10):1;if(!(q>0))q=1;
    if(excl&&name.indexOf(excl)>=0){sets+=q;return;}
    var lab=it.querySelector('.js-cart-item-promotion-label');
    /* TN deja el texto de la etiqueta aunque la oculte por debajo del primer escalón: basta con que exista. */
    if(lab&&/comprando|%\s*off/i.test(lab.textContent))promo=true;
    count+=q;
   });
   /* Por debajo del primer escalón TN no expone la promo en el carrito: la barra se muestra con ≥1 decant. */
   goal.hidden=!(count>0||promo);if(goal.hidden){lastQ=0;pendingQ=0;return;}
   var terminal=tiers[tiers.length-1],max=terminal.q,reached=null,next=null;
   tiers.forEach(function(t){if(count>=t.q)reached=t;else if(!next)next=t;});
   var nowQ=reached?reached.q:0,levelUp=lastQ!==null&&nowQ>lastQ;if(nowQ<lastQ)pendingQ=0;lastQ=nowQ;
   var faltan=next?next.q-count:0,s=faltan===1?'':'s',msg;
   if(!reached)msg='Agrega '+faltan+' decant'+s+' más y llévate '+next.pct+'% OFF en todos tus decants';
   else if(next)msg='¡Tienes '+reached.pct+'% OFF en tus decants! Agrega '+faltan+' más y sube a '+next.pct+'%';
   else msg='¡Tienes '+reached.pct+'% OFF en tus decants, el máximo!';
   var m=goal.querySelector('[data-sc-tier-message]');if(m&&m.textContent!==msg){
    var message=document.createDocumentFragment();
    msg.split(/(\d+%(?: OFF)?)/).forEach(function(part){if(/^\d+%/.test(part)){var emphasis=document.createElement('strong');emphasis.textContent=part;message.appendChild(emphasis);}else message.appendChild(document.createTextNode(part));});
    m.replaceChildren(message);
   }
   var counter=goal.querySelector('[data-sc-tier-counter]'),counterText=(goal.dataset.scTierCountMessage||'').replace(/\{1\}/g,String(count)).replace(/\{2\}/g,String(max));
   if(counter&&counter.textContent!==counterText)counter.textContent=counterText;
   /* Cada etapa conserva su tramo igual en todos los anchos. */
   var unitRatio=Math.max(0,Math.min(1,count/max)),visualRatio=1,previous=0;
   for(var i=0;i<tiers.length;i++){
    if(count<tiers[i].q){visualRatio=(i+(count-previous)/(tiers[i].q-previous))/tiers.length;break;}
    previous=tiers[i].q;
   }
   visualRatio=Math.max(0,Math.min(1,visualRatio));
   var fill=goal.querySelector('[data-sc-tier-fill]');if(fill)fill.style.width=(visualRatio*100)+'%';
   var track=goal.querySelector('.sc-tier-goal__track'),pct=String(Math.round(unitRatio*100));
   if(track&&track.getAttribute('aria-valuenow')!==pct)track.setAttribute('aria-valuenow',pct);
   var valueText=mobile.matches?counterText+'. '+msg:count+' decant'+(count===1?'':'s')+'. '+msg;
   if(track&&track.getAttribute('aria-valuetext')!==valueText)track.setAttribute('aria-valuetext',valueText);
   function presentStep(el,q){
    var index=tiers.findIndex(function(t){return t.q===q;});
    el.style.setProperty('--sc-tier-position',((index+1)/tiers.length*100)+'%');
    el.classList.toggle('is-terminal',q===max);
    el.classList.toggle('is-on',count>=q);
    el.classList.toggle('is-next',!!next&&q===next.q);
    el.classList.toggle('is-complete',!next&&q===max);
   }
   goal.querySelectorAll('[data-sc-tier-mark]').forEach(function(mk){var q=parseInt(mk.getAttribute('data-sc-tier-mark'),10);presentStep(mk,q);mk.classList.toggle('is-last-reached',!!reached&&q===reached.q);});
   goal.querySelectorAll('[data-sc-tier-step]').forEach(function(st){
    var q=parseInt(st.getAttribute('data-sc-tier-step'),10),prefix=st.querySelector('.sc-tier-goal__quantity');
    if(!st._scTierParts&&prefix)st._scTierParts=[prefix.textContent,st.textContent.slice(prefix.textContent.length)];
    /* Un solo text node fuera de móvil conserva el espaciado tipográfico original. */
    if(mobile.matches&&!prefix&&st._scTierParts){
     prefix=document.createElement('span');prefix.className='sc-tier-goal__quantity';prefix.textContent=st._scTierParts[0];
     st.replaceChildren(prefix,document.createTextNode(st._scTierParts[1]));
    }else if(!mobile.matches&&prefix)st.replaceChildren(document.createTextNode(st._scTierParts?st._scTierParts.join(''):st.textContent));
    if(mobile.matches&&q===max&&prefix){var label=prefix.nextSibling,labelText=String(terminal.pct)+'%';if(label&&label.textContent!==labelText)label.textContent=labelText;}
    presentStep(st,q);
   });
   var note=goal.querySelector('[data-sc-tier-note]');if(note)note.hidden=!(sets>0&&!reached);
   goal.setAttribute('data-sc-tier-count',String(count));
   if(levelUp)celebrate(goal,nowQ);
  }
  function schedule(){if(queued)return;queued=true;setTimeout(render,16);}
  if(mobile.addEventListener)mobile.addEventListener('change',schedule);else mobile.addListener(schedule);
  /* El tema re-dibuja el cajón después de avisar cart.updated: se vuelve a calcular en el momento y tras un respiro. */
  function later(){schedule();setTimeout(schedule,350);setTimeout(schedule,1200);}
  document.addEventListener('cart.updated',later);
  cart.addEventListener('input',function(e){if(e.target&&e.target.matches&&e.target.matches('.js-cart-quantity-input'))later();});
  cart.addEventListener('change',function(e){if(e.target&&e.target.matches&&e.target.matches('.js-cart-quantity-input'))later();});
  cart.addEventListener('click',function(e){if(e.target&&e.target.closest&&e.target.closest('.js-cart-quantity-btn,.js-cart-item-delete-button,[data-component="line-item.remove"]'))later();});
  new MutationObserver(function(records){if(records.some(function(r){return (r.type==='childList'&&cart.contains(r.target))||(r.type==='attributes'&&r.target.matches&&r.target.matches('.js-cart-quantity-input,.js-cart-item-promotion-label,.js-cart-subtotal'));}))schedule();}).observe(cart,{subtree:true,childList:true,attributes:true,attributeFilter:['value','style','class','data-priceraw']});
  render();
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initTierGoal,{once:true});else initTierGoal();
})();


/* Cuenta regresiva Buen Fin (11-nov-2026, diseño v3, con color): mientras dure la promo, la barra de anuncios deja de correr como
   marquesina y muestra una fila fija y centrada: el aviso que contenga "Buen Fin" + un contador en pastillas
   (días, horas, minutos, segundos) en el rojo del Buen Fin; el porcentaje del aviso se resalta. En pantallas anchas también muestra el otro aviso de la barra.
   Fin de la promo: 17-nov-2026 23:59:59, hora del centro de México. Al vencer se quita sola y la marquesina vuelve.
   El texto del aviso se edita en Personalizar diseño; este bloque solo arma la fila y el reloj (estilos incluidos aquí).
   17-nov-2026: toda la fila es una liga al armador de sets (/set-buen-fin/): texto subrayado + flecha con pulso; en celular se oculta
   la etiqueta roja para que quepa el texto, y la pastilla de días desaparece cuando ya es 0.
   Para quitarlo: borrar este bloque completo y el aviso "BUEN FIN" de la barra. */
(function(){
 'use strict';
 var END=Date.parse('2026-11-18T05:59:59Z'),MARK=/buen fin/i,HREF='/set-buen-fin/',timer=null,row=null,cells=null,clockEl=null;
 var CSS='.adbar.sc-adbar--promo{position:relative}'
  +'.adbar.sc-adbar--promo .adbar-marquee{position:absolute;left:0;right:0;top:0;visibility:hidden;pointer-events:none}'
  +'.sc-adbar-promo{position:relative;display:flex;align-items:center;justify-content:center;gap:12px;width:100%;padding:0 12px;box-sizing:border-box;white-space:nowrap;font-family:var(--sc-font-body,"Instrument Sans",sans-serif);font-size:12px;line-height:16px;font-weight:400;color:#f8f6f2!important;text-decoration:none!important;cursor:pointer;-webkit-tap-highlight-color:rgba(255,255,255,.12)}'
  +'.sc-adbar-promo::after{content:"";position:absolute;left:0;right:0;top:-8px;bottom:-8px}'
  +'.sc-adbar-promo__msg u{text-decoration:underline;text-decoration-thickness:1.5px;text-underline-offset:3px;font-weight:600;color:#fff}'
  +'.sc-adbar-promo__go{display:inline-grid;place-items:center;width:16px;height:16px;margin-left:7px;border-radius:50%;background:#fff;color:#111;font-size:11px;line-height:1;font-weight:700;vertical-align:-3px;animation:sc-adbar-go 1.6s ease-out infinite}'
  +'@keyframes sc-adbar-go{0%{box-shadow:0 0 0 0 rgba(255,255,255,.8);transform:translateX(0)}45%{transform:translateX(2px)}70%{box-shadow:0 0 0 7px rgba(255,255,255,0)}100%{box-shadow:0 0 0 0 rgba(255,255,255,0);transform:translateX(0)}}'
  +'@media(prefers-reduced-motion:reduce){.sc-adbar-promo__go{animation:none}}'
  +'.sc-adbar-promo__unit[hidden]{display:none}'
  +'.sc-adbar-promo__msg strong{display:none;font-weight:600;font-size:.86em;line-height:1.5;letter-spacing:.16em;text-transform:uppercase;margin-right:8px;padding:1px 6px 1px 8px;border-radius:5px;background:#d3241c;color:#fff}'
  +'.sc-adbar-promo__msg em{font-style:normal;font-weight:600;color:#ff6a5e}'
  +'.sc-adbar-promo__sep{flex:none;width:1px;height:14px;background:rgba(248,246,242,.26)}'
  +'.sc-adbar-promo__other,.sc-adbar-promo__other+.sc-adbar-promo__sep,.sc-adbar-promo__label{display:none}'
  +'.sc-adbar-promo__label{font-size:10px;letter-spacing:.18em;text-transform:uppercase;color:rgba(248,246,242,.66)}'
  +'.sc-adbar-promo__clock{display:inline-flex;gap:4px;font-variant-numeric:tabular-nums}'
  +'.sc-adbar-promo__unit{display:inline-flex;align-items:baseline;gap:2px;padding:1px 6px;border:1px solid rgba(232,62,52,.62);border-radius:6px;background:rgba(211,36,28,.2)}'
  +'.sc-adbar-promo__unit b{font-weight:600;font-size:12px;line-height:16px;min-width:15px;text-align:center}'
  +'.sc-adbar-promo__unit i{font-style:normal;font-size:9px;line-height:16px;letter-spacing:.06em;text-transform:uppercase;color:#ff9087}'
  +'@media(max-width:389px){.sc-adbar-promo{gap:9px;padding:0 8px}}'
  +'@media(max-width:339px){.sc-adbar-promo__unit:last-child{display:none}}'
  +'@media(max-width:359px){.sc-adbar-promo{gap:7px;padding:0 6px;font-size:11px}.sc-adbar-promo__unit{padding:1px 4px}.sc-adbar-promo__msg strong{letter-spacing:.08em;margin-right:5px;padding:1px 4px 1px 5px}}'
  +'@media(min-width:768px){.sc-adbar-promo{gap:16px;font-size:13px}.sc-adbar-promo__msg strong{display:inline-block}.sc-adbar-promo__label{display:inline}.sc-adbar-promo__unit{padding:2px 7px}.sc-adbar-promo__unit b{font-size:13px}}'
  +'@media(min-width:1100px){.sc-adbar-promo__other{display:inline}.sc-adbar-promo__other+.sc-adbar-promo__sep{display:block}}';
 function pad(n){return n<10?'0'+n:String(n);}
 function el(tag,cls,text){var e=document.createElement(tag);if(cls)e.className=cls;if(text!=null)e.textContent=text;return e;}
 function build(){
  var bar=document.querySelector('.adbar');if(!bar)return null;
  var items=bar.querySelectorAll('.adbar-item'),promo='',other='';
  for(var i=0;i<items.length;i++){var tx=(items[i].textContent||'').replace(/\s+/g,' ').trim();if(!tx)continue;if(MARK.test(tx)){if(!promo)promo=tx;}else if(!other)other=tx;}
  if(!promo)return null;
  if(!document.getElementById('sc-adbar-promo-style')){var st=el('style');st.id='sc-adbar-promo-style';st.textContent=CSS;document.head.appendChild(st);}
  var r=el('a','sc-adbar-promo');r.href=/^\/set-buen-fin\/?$/.test(location.pathname)?'#scc-tienda':HREF;
  if(other){r.appendChild(el('span','sc-adbar-promo__other',other));r.appendChild(el('i','sc-adbar-promo__sep'));}
  var parts=promo.split('·'),head=parts.shift().trim(),tail=parts.join('·').trim();
  var msg=el('span','sc-adbar-promo__msg'),link=el('u');msg.appendChild(el('strong','',head));(tail||'Arma tu set').split(/(\d+\s?%(?:\s?OFF)?)/i).forEach(function(part){if(!part)return;if(/^\d+\s?%/.test(part))link.appendChild(el('em','',part));else link.appendChild(document.createTextNode(part));});msg.appendChild(link);var go=el('b','sc-adbar-promo__go','\u2192');go.setAttribute('aria-hidden','true');msg.appendChild(go);r.appendChild(msg);
  r.appendChild(el('i','sc-adbar-promo__sep'));
  r.appendChild(el('span','sc-adbar-promo__label','Termina en'));
  var clock=el('span','sc-adbar-promo__clock');clock.setAttribute('role','timer');clockEl=clock;cells={};
  [['d','d'],['h','h'],['m','m'],['s','s']].forEach(function(u){var c=el('span','sc-adbar-promo__unit');cells[u[0]]=c.appendChild(el('b','','00'));c.appendChild(el('i','',u[1]));clock.appendChild(c);});
  r.appendChild(clock);bar.appendChild(r);bar.classList.add('sc-adbar--promo');return r;
 }
 function stop(){
  if(row){row.remove();row=null;}
  var bar=document.querySelector('.adbar');if(bar)bar.classList.remove('sc-adbar--promo');
  if(timer){clearInterval(timer);timer=null;}
 }
 function tick(){
  try{
   var left=END-Date.now();if(left<=0){stop();return;}
   if(!row||!row.isConnected)row=build();if(!row)return;
   var s=Math.floor(left/1000),d=Math.floor(s/86400);s-=d*86400;var h=Math.floor(s/3600);s-=h*3600;var m=Math.floor(s/60);s-=m*60;
   var v={d:pad(d),h:pad(h),m:pad(m),s:pad(s)};
   for(var k in v)if(cells[k].textContent!==v[k])cells[k].textContent=v[k];
   if(cells.d.parentNode.hidden!==(d===0))cells.d.parentNode.hidden=(d===0);
   var label='Termina en '+d+' días, '+h+' horas, '+m+' minutos';if(clockEl&&clockEl.getAttribute('aria-label')!==label)clockEl.setAttribute('aria-label',label);
  }catch(e){}
 }
 function start(){if(END<=Date.now())return;tick();timer=setInterval(tick,1000);}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})();
