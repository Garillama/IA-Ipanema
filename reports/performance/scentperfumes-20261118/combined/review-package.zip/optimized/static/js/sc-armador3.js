/* "Arma tu set · Buen Fin" (/set-buen-fin/) — versión 3.2 del armador, 16-nov-2026.
   La selección ES el carrito real de la tienda: cada perfume que se toca se guarda en el carrito en segundo plano
   (una petición a la vez; Tiendanube tarda ~1.3 s por perfume y no acepta varias juntas), así "Pagar ahora" ya no espera.
   Al cargar, la página lee el carrito real (LS.cart) y parte de ahí; no usa memoria del navegador.
   El descuento NO se calcula aquí: lo aplica la promo automática de Tiendanube; esta página solo lo muestra.
   Los sets por ocasión se editan en SETS (por "handle" del producto, 6 por set); un perfume sin existencia en 5 ml se omite solo. */
(function () {
  'use strict';
  var root = document.querySelector('[data-scc]');
  if (!root) return;
  var D = document, mt = D.createElement('meta'); mt.name = 'robots'; mt.content = 'noindex,nofollow'; D.head.appendChild(mt);
  root.classList.add('scc-js');
  /* al volver con "atrás" el navegador revive la página congelada: se recarga para leer el carrito real */
  window.addEventListener('pageshow', function (e) { if (e.persisted) location.reload(); });

  var TIERS = [[4, 10], [6, 15], [9, 20]];
  var END = Date.parse('2026-11-18T05:59:59Z'); /* 17-nov 23:59:59, hora del centro */
  var SHIP = 99, MAX = 20, PAGE = 12, SIZES = ['3', '5', '10', '30'], SET_SIZE = '5';
  var SETS = {
    H: [
      ['Oficina y diario', 'Frescos y limpios para diario, con 2 Louis Vuitton nuevos.', ['tea-storm', 'ink-mark', 'bleu-de-chanel-edp', 'y-edp', 'acqua-di-gio-parfum', 'lhomme']],
      ['Para citas', 'Dulces y especiados para salir de noche.', ['le-male-elixir', 'stronger-with-you-intensely-1', 'uomo-born-in-roma-intense', 'spicebomb-extreme', 'le-beau-le-parfum', 'noir-extreme']],
      ['Para oler caro', 'Nicho y alta gama para probar antes de la botella.', ['aventus', 'layton-parfums-de-marly', 'silver-mountain-water', 'ombre-nomade', 'ombre-leather', 'sauvage-elixir-2']],
      ['Calor y gimnasio', 'Frescos e intensos para clima caliente.', ['allure-homme-sport-eau-extreme-1', 'dylan-blue', 'hawas-ice', 'cedrat-boise-edp', 'eros-energy', 'costa-azzura-parfum']]
    ],
    M: [
      ['Dulces para salir', 'Cálidos y golosos para la noche.', ['good-girl', 'black-opium', 'la-vie-est-belle', 'paradoxe', 'flowerbomb', 'coco-mademoiselle']],
      ['Frescos para diario', 'Limpios y florales para oficina o escuela.', ['light-blue-for-her', 'bright-crystal', 'chance-eau-fraiche', 'libre-edp', 'lazy-sunday-morning', 'french-riviera']],
      ['Para oler caro', 'Nicho para probar antes de la botella.', ['delina', 'baccarat-rouge-540-edp', 'city-of-stars', 'erba-pura', 'santal-33', 'mojave-ghost']]
    ],
    U: [
      ['Frescos de nicho', 'Cítricos elegantes que le quedan a cualquiera.', ['afternoon-swim', 'millesime-imperial', 'silver-mountain-water', 'torino-21', 'vibrato', 'meteore']],
      ['Cálidos para el frío', 'Vainilla, tabaco y maderas para otoño e invierno.', ['tobacco-vanille', 'naxos', 'by-the-fireplace', 'angels-share', 'bianco-latte', 'jazz-club']]
    ]
  };
  var st = { mode: 'sets', tab: 'H', fam: 'all', gen: 'all', q: '', sel: [], shown: PAGE, tier: 0, det: null, open: null };
  var DATA = [], BY = {}, BYH = {}, VAR = {}, TOP = {}, el = {}, lastTap = null;
  var IC = {}, ICG = 9, INT = ['Muy suave', 'Suave', 'Media', 'Alta', 'Muy alta'];
  var real = {}, cartQty = 0, dirty = false, sync = { ready: false, running: false, err: false, want: false, going: false, tries: 0 };
  var $ = function (s) { return root.querySelector(s); }, $d = function (s) { return D.querySelector(s); };
  var calm = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function money(n) { n = Math.round(n * 100) / 100; var s = n.toFixed(2).replace(/\.00$/, ''); return '$' + s.replace(/\B(?=(\d{3})+(?!\d))/g, ','); }
  function norm(s) { return String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, ''); }
  function img(u, w) { return String(u || '').replace(/-\d+-\d+\.(jpe?g|png|webp)$/i, '-' + w + '-0.$1'); }
  function vOf(it, size) { for (var i = 0; i < it.vs.length; i++) if (it.vs[i][1] === size) return it.vs[i]; return null; }
  function ok(it, size) { var v = vOf(it, size); return v && v[4] ? v : null; }
  function firstOk(it) { return ok(it, SET_SIZE) || ok(it, '3') || ok(it, '10') || ok(it, '30'); }
  function count() { return st.sel.reduce(function (a, l) { return a + l.q; }, 0); }
  function qty(id, size) { return st.sel.reduce(function (a, l) { return a + (l.id === id && (!size || l.s === size) ? l.q : 0); }, 0); }
  function pctFor(n) { var p = 0; TIERS.forEach(function (t) { if (n >= t[0]) p = t[1]; }); return p; }
  function nextTier(n) { for (var i = 0; i < TIERS.length; i++) if (n < TIERS[i][0]) return TIERS[i]; return null; }
  /* notas con ícono e intensidad: los mismos datos e ilustraciones de la ficha del producto */
  function ico(lab) { var i = IC[lab]; return i == null ? '' : '<i class="scc-ic" style="background-position:' + (i % ICG) * 100 / (ICG - 1) + '% ' + Math.floor(i / ICG) * 100 / (ICG - 1) + '%"></i>'; }
  function notes(it) { return ((it.no && it.no.length) ? it.no : it.f).map(function (n) { return '<span>' + ico(n) + esc(n) + '</span>'; }).join(''); }
  function bars(n) { for (var s = '', k = 1; k <= 5; k++) s += '<i' + (k <= n ? ' class="is-on"' : '') + '></i>'; return '<span class="scc-bars" aria-hidden="true">' + s + '</span>'; }
  function subtotal() { return st.sel.reduce(function (a, l) { var v = vOf(BY[l.id], l.s); return a + (v ? v[2] * l.q : 0); }, 0); }

  /* ---------- carrito real: leer, comparar y guardar en segundo plano ---------- */
  function readCart(list, idKey) {
    real = {}; cartQty = 0;
    (list || []).forEach(function (p) { var vid = +p.variant_id, q = +p.quantity || 0; cartQty += q; if (VAR[vid] && q > 0) real[vid] = { item: +p[idKey], q: q }; });
  }
  function selFromCart() { st.sel = Object.keys(real).map(function (vid) { return { id: VAR[vid].it.id, s: VAR[vid].s, q: real[vid].q }; }); }
  function badge() { [].forEach.call(D.querySelectorAll('.js-cart-widget-amount'), function (n) { n.textContent = cartQty; }); }
  function pending() {
    var want = {}, list = [];
    st.sel.forEach(function (l) { var v = vOf(BY[l.id], l.s); if (v) want[v[0]] = (want[v[0]] || 0) + l.q; });
    Object.keys(real).forEach(function (vid) { var w = want[vid] || 0; if (real[vid].q > w) list.push({ t: 'set', vid: +vid, item: real[vid].item, q: w }); });
    Object.keys(want).forEach(function (vid) { var r = real[vid] ? real[vid].q : 0; if (want[vid] > r) list.push({ t: 'add', vid: +vid, q: want[vid] - r }); });
    return list;
  }
  function post(url, body) {
    var ctl = window.AbortController ? new AbortController() : null, t = setTimeout(function () { if (ctl) ctl.abort(); }, 15000);
    return fetch(url, { method: 'POST', credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json' }, body: body, signal: ctl ? ctl.signal : undefined })
      .then(function (r) { clearTimeout(t); return r.json(); }, function (e) { clearTimeout(t); throw e; });
  }
  function doOp(op) {
    var b = new URLSearchParams();
    if (op.t === 'add') {
      var x = VAR[op.vid]; b.set('add_to_cart', x.it.id); b.set('variation[0]', x.s + ' ML'); b.set('quantity', op.q);
      return post('/comprar/', b).then(function (j) { if (!j || !j.success) { var e = new Error('stock'); e.stock = true; throw e; } return j; });
    }
    (op.many || [op]).forEach(function (o) { b.set('quantity[' + o.item + ']', o.q); }); b.set('cart_page', '0');
    return post('/cart/update/', b).then(function (j) { if (!j || !j.success) throw new Error('update'); return j; });
  }
  /* el HTML puede venir de la memoria del navegador (por ejemplo al volver con "atrás"), así que el carrito real
     se confirma siempre con el servidor: la página del carrito trae LS.cart recién hecho (~0.8 s) */
  function freshCart() {
    var ctl = window.AbortController ? new AbortController() : null, t = setTimeout(function () { if (ctl) ctl.abort(); }, 8000);
    return fetch('/comprar/?_=' + Date.now(), { credentials: 'same-origin', cache: 'no-store', signal: ctl ? ctl.signal : undefined })
      .then(function (r) { return r.text(); })
      .then(function (html) { clearTimeout(t); var m = html.match(/LS\.cart\s*=\s*(\{[\s\S]*?\});\s*\n/); if (!m) throw new Error('sin carrito'); return JSON.parse(m[1]).items || []; });
  }
  function confirmCart() {
    freshCart().then(function (items) {
      readCart(items, 'item_id'); badge();
      if (!dirty) { selFromCart(); st.tier = pctFor(count()); paintTray(false); paintCards(false); if (el.sheet.classList.contains('is-on')) paintSheet(); }
    }).catch(function () {}).then(function () { sync.ready = true; paintSync(); run(); });
  }
  function run() {
    if (!sync.ready || sync.running || sync.going) return;
    var list = pending();
    if (!list.length) { sync.err = false; sync.tries = 0; paintSync(); if (sync.want) goPay(); return; }
    sync.running = true; sync.err = false; paintSync();
    var op = list[0];
    if (op.t === 'set') op = { t: 'set', many: list.filter(function (o) { return o.t === 'set'; }) };
    doOp(op).then(function (j) {
      sync.running = false; sync.tries = 0;
      if (j.cart && j.cart.products) readCart(j.cart.products, 'id');
      badge(); run();
    }).catch(function (e) {
      sync.running = false;
      if (e && e.stock) { /* se agotó mientras lo elegía: se quita del set y se avisa */
        var x = VAR[op.vid], v = vOf(x.it, x.s); if (v) v[4] = 0;
        st.sel = st.sel.filter(function (l) { return !(l.id === x.it.id && l.s === x.s); });
        toast(esc(x.it.t) + ' de ' + x.s + ' ml se acaba de agotar');
        repaint(); run(); return;
      }
      sync.tries++;
      if (sync.tries <= 2) { setTimeout(run, 800); return; }
      sync.err = true; sync.want = false; paintSync();
    });
  }
  function pay() {
    if (!count() || sync.going) return;
    sync.want = true; sync.tries = 0; sync.base = Math.max(1, pending().length); paintSync(); run();
  }
  function goPay() {
    sync.going = true; sync.want = false; paintSync();
    var f = D.createElement('form'); f.method = 'post'; f.action = '/comprar/'; f.style.display = 'none';
    var inp = D.createElement('input'); inp.type = 'hidden'; inp.name = 'go_to_checkout'; inp.value = 'Iniciar compra'; f.appendChild(inp);
    D.body.appendChild(f); f.submit();
    setTimeout(function () { sync.going = false; paintSync(); }, 12000); /* si el navegador no navegó, el botón vuelve a servir */
  }
  function paintSync() {
    if (!el.cta) return;
    var left = pending().length, busy = sync.running || left > 0 || (!sync.ready && dirty), n = count(), pct = pctFor(n), s = subtotal(), label = null;
    if (sync.going) label = 'Vamos al pago…';
    else if (sync.want && busy) { var base = Math.max(sync.base || 1, left), done = Math.min(base, base - left + 1); label = 'Guardando tu set… ' + done + ' de ' + base; }
    else if (sync.err) label = 'Reintentar';
    el.cta.disabled = !n || sync.going || (sync.want && busy);
    el.cta.textContent = label || (pct ? 'Pagar ahora · ahorras ' + money(Math.round(s * pct / 100)) : 'Pagar ahora');
    el.cta2.disabled = el.cta.disabled; el.cta2.textContent = label || 'Pagar ahora';
    var wait = sync.going || (sync.want && busy), prog = sync.going ? 100 : (sync.want && busy ? Math.round(100 * (Math.max(sync.base || 1, left) - left + 0.5) / Math.max(sync.base || 1, left)) : 0);
    [el.cta, el.cta2].forEach(function (b) { b.classList.toggle('is-wait', wait); b.style.setProperty('--p', prog + '%'); });
    el.err.hidden = el.err2.hidden = !sync.err;
    el.bar.hidden = !busy;
  }

  /* ---------- selección (se pinta al instante; el carrito se pone al día detrás) ---------- */
  function add(id, size) {
    if (count() >= MAX) { toast('Máximo ' + MAX + ' decants por set'); return; }
    var it = BY[id]; if (!it || !ok(it, size)) return;
    var line = st.sel.filter(function (l) { return l.id === id && l.s === size; })[0];
    if (line) line.q++; else st.sel.push({ id: id, s: size, q: 1 });
    fly(); changed(id);
  }
  function drop(id, size) {
    st.sel = st.sel.filter(function (l) { return !(l.id === id && l.s === size); });
    changed(id);
  }
  function toggle(id, size) { if (qty(id, size)) drop(id, size); else add(id, size); }
  function resize(id, from, to) {
    var it = BY[id]; if (!ok(it, to) || from === to) return;
    var a = st.sel.filter(function (l) { return l.id === id && l.s === from; })[0]; if (!a) return;
    var b = st.sel.filter(function (l) { return l.id === id && l.s === to; })[0];
    if (b) { b.q += a.q; st.sel.splice(st.sel.indexOf(a), 1); } else a.s = to;
    st.open = null; changed();
  }
  function repaint(id) {
    var p = pctFor(count());
    paintTray(true);
    if (el.sheet.classList.contains('is-on')) paintSheet();
    if (st.det && el.det.classList.contains('is-on')) paintDetail();
    if (id && p === st.tier) paintCard(id); else paintCards(false);
    if (p > st.tier) celebrate(p);
    st.tier = p;
  }
  function changed(id) { dirty = true; repaint(id); run(); }
  /* bolita que viaja del dedo a la barra */
  function fly() {
    if (calm || !lastTap || !el.tray || el.sheet.classList.contains('is-on')) return;
    var f = D.createElement('i'); f.className = 'scc-fly'; f.style.left = lastTap.x + 'px'; f.style.top = lastTap.y + 'px'; D.body.appendChild(f);
    var r = el.tray.getBoundingClientRect(), dx = (r.left + r.width * 0.2) - lastTap.x, dy = (r.top + 28) - lastTap.y;
    requestAnimationFrame(function () { requestAnimationFrame(function () { f.style.transform = 'translate(' + dx + 'px,' + dy + 'px) scale(.5)'; f.style.opacity = '.2'; }); });
    setTimeout(function () { f.remove(); }, 620);
  }

  /* ---------- reloj ---------- */
  function tick() {
    var ms = END - Date.now(), box = $('[data-scc-timer]');
    if (!box) return;
    if (ms <= 0) { box.hidden = true; return; }
    var s = Math.floor(ms / 1000), d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60), x = s % 60;
    function p(n) { return (n < 10 ? '0' : '') + n; }
    el.timer.innerHTML = '<span>' + p(d) + '<small>DÍAS</small></span><span>' + p(h) + '<small>HRS</small></span><span>' + p(m) + '<small>MIN</small></span><span>' + p(x) + '<small>SEG</small></span>';
  }

  /* ---------- modo: set armado o a mi gusto ---------- */
  function paintMode() {
    [].forEach.call(root.querySelectorAll('[data-mode]'), function (b) { var on = b.getAttribute('data-mode') === st.mode; b.classList.toggle('is-on', on); b.setAttribute('aria-pressed', on); });
    [].forEach.call(root.querySelectorAll('[data-panel]'), function (p) { p.hidden = p.getAttribute('data-panel') !== st.mode; });
  }

  /* ---------- sets por ocasión ---------- */
  function setItems(def) { return def[2].map(function (h) { return BYH[h]; }).filter(function (it) { return it && ok(it, SET_SIZE); }); }
  function paintSets() {
    [].forEach.call(el.tabs.children, function (b) { b.classList.toggle('is-on', b.getAttribute('data-tab') === st.tab); });
    el.sets.innerHTML = (SETS[st.tab] || []).map(function (def, i) {
      var its = setItems(def); if (its.length < 4) return '';
      var pct = pctFor(its.length), tot = its.reduce(function (a, it) { return a + ok(it, SET_SIZE)[2]; }, 0), fin = Math.round(tot * (1 - pct / 100));
      return '<article class="scc-set"><div class="scc-collage is-6">' +
        its.slice(0, 6).map(function (it) { return '<img alt="' + esc(it.t) + '" width="130" height="130" src="' + esc(img(it.i, 240)) + '">'; }).join('') +
        '<span>' + its.length + ' decants · ' + pct + '% OFF</span></div>' +
        '<h3>' + def[0] + '</h3><p>' + def[1] + '</p>' +
        '<ul>' + its.map(function (it) { return '<li>' + esc(it.t) + '</li>'; }).join('') + '</ul>' +
        '<div class="scc-set-foot"><div class="scc-set-price"><b>' + money(fin) + '</b><s>' + money(tot) + '</s><i>−' + pct + '%</i></div>' +
        '<small>' + its.length + ' decants de ' + SET_SIZE + ' ml · ' + money(Math.round(fin / its.length)) + ' cada uno</small>' +
        '<button type="button" class="scc-btn" data-buy="' + i + '">Comprar este set</button></div></article>';
    }).join('');
    el.sets.scrollLeft = 0; el.sets.classList.remove('scc-anim'); void el.sets.offsetWidth; el.sets.classList.add('scc-anim');
  }
  /* agrega el set a lo que ya haya (sin duplicar ni borrar nada) y abre "Tu set" al instante */
  function buySet(i) {
    var def = (SETS[st.tab] || [])[i]; if (!def) return;
    setItems(def).forEach(function (it) { if (!qty(it.id, SET_SIZE) && count() < MAX) st.sel.push({ id: it.id, s: SET_SIZE, q: 1 }); });
    dirty = true; st.tier = pctFor(count()); st.open = null;
    paintTray(false); paintCards(false); sheet(true); run();
  }

  /* ---------- tarjetas ---------- */
  function visible() {
    var q = norm(st.q), f = st.fam, g = st.gen;
    return DATA.filter(function (it) {
      if (q && norm(it.t + ' ' + it.v).indexOf(q) < 0) return false;
      if (g === 'H' || g === 'M') { if (!(it.g === g || it.g === 'U')) return false; }
      if (f === 'top') return !!TOP[it.id];
      if (f !== 'all') return it.f.indexOf(f) > -1;
      return true;
    });
  }
  function sizeRows(it) {
    var pct = pctFor(count());
    return '<div class="scc-sizes-h"><span>Tamaño</span><span>' + (pct ? '<em>Precio −' + pct + '%</em>' : 'Precio') + '</span></div>' + SIZES.map(function (z) {
      var v = vOf(it, z), on = qty(it.id, z);
      if (!v || !v[4]) return '<button type="button" class="scc-sz" disabled aria-label="' + z + ' ml agotado"><b>' + z + ' ml</b><span>Agotado</span></button>';
      var price = '<span' + (pct ? ' class="is-off"' : '') + '>' + money(pct ? Math.round(v[2] * (1 - pct / 100)) : v[2]) + '</span>';
      return '<button type="button" class="scc-sz' + (on ? ' is-on' : '') + '" data-act="toggle" data-s="' + z + '" aria-pressed="' + (on ? 'true' : 'false') + '" aria-label="' + (on ? 'Quitar ' : 'Agregar ') + esc(it.t) + ' ' + z + ' ml"><b>' + z + ' ml</b>' + price + '<i>' + (on ? '✓' : '+') + '</i></button>';
    }).join('');
  }
  function cardHTML(it) {
    var n = qty(it.id);
    return '<article class="scc-card' + (n ? ' is-in' : '') + '" data-id="' + it.id + '">' +
      '<button type="button" class="scc-card-open" data-act="open" aria-label="Ver ' + esc(it.t) + '">' +
      '<span class="scc-card-img"><img loading="lazy" decoding="async" width="330" height="330" src="' + esc(img(it.i, 480)) + '" alt="' + esc(it.t + ' de ' + it.v) + '">' +
      (TOP[it.id] ? '<span class="scc-tag">Más vendido</span>' : '') + (n ? '<span class="scc-badge">' + n + '</span>' : '') + '</span>' +
      '<span class="scc-card-t"><span class="scc-brand">' + esc(it.v) + '</span><span class="scc-name' + (it.t.length > 28 ? ' is-xlong' : it.t.length > 20 ? ' is-long' : '') + '">' + esc(it.t) + '</span>' +
      '<span class="scc-prof">' + notes(it) + '</span>' +
      '<span class="scc-int">' + (it['in'] ? '<em>Intensidad</em>' + bars(it['in']) : '') + '</span>' +
      '<span class="scc-rate">' + (it.r ? '<b>★</b> ' + it.r.toFixed(1) + ' · ' + it.rc + ' reseñas' : '') + '</span></span></button>' +
      '<div class="scc-sizes">' + sizeRows(it) + '</div></article>';
  }
  function paintCards(anim) {
    var list = visible();
    el.count.textContent = list.length + (list.length === 1 ? ' perfume' : ' perfumes');
    if (!list.length) { el.grid.innerHTML = '<div class="scc-empty">No encontramos ese perfume. Prueba otra búsqueda o quita el filtro.</div>'; el.more.hidden = true; return; }
    el.grid.innerHTML = list.slice(0, st.shown).map(cardHTML).join('');
    el.grid.classList.remove('scc-anim'); if (anim) { void el.grid.offsetWidth; el.grid.classList.add('scc-anim'); }
    el.more.hidden = list.length <= st.shown;
    el.more.textContent = 'Ver ' + Math.min(PAGE, list.length - st.shown) + ' perfumes más';
  }
  function paintCard(id) {
    var c = el.grid.querySelector('[data-id="' + id + '"]'); if (!c) return;
    el.grid.classList.remove('scc-anim');
    var t = D.createElement('div'); t.innerHTML = cardHTML(BY[id]); c.parentNode.replaceChild(t.firstChild, c);
  }

  /* ---------- detalle de un perfume ---------- */
  function paintDetail() {
    var it = BY[st.det]; if (!it) return;
    var pics = [it.i, it.n].filter(Boolean);
    el.detBody.innerHTML = '<div class="scc-det-gal">' + pics.map(function (u, i) { return '<img alt="' + esc((i ? 'Notas de ' : '') + it.t) + '" src="' + esc(img(u, 480)) + '">'; }).join('') + '</div>' +
      '<div class="scc-det-b" data-id="' + it.id + '"><span class="scc-brand">' + esc(it.v) + '</span><span class="scc-name' + (it.t.length > 32 ? ' is-xlong' : it.t.length > 24 ? ' is-long' : '') + '">' + esc(it.t) + '</span>' +
      (it.r ? '<span class="scc-rate"><b>★</b> ' + it.r.toFixed(1) + ' · ' + it.rc + ' reseñas</span>' : '') +
      '<div class="scc-pro"><div class="scc-pro-h"><span>Perfil del aroma</span>' + (it['in'] ? '<span>Intensidad <b>' + INT[it['in'] - 1] + '</b>' + bars(it['in']) + '</span>' : '') + '</div>' +
      '<div class="scc-prof">' + notes(it) + '</div></div>' +
      '<h4>Toca el tamaño que quieres</h4>' + sizeRows(it) +
      '<p class="scc-det-note">Perfume 100% original, en atomizador de viaje.</p>' +
      '<button type="button" class="scc-btn" data-scc-det-close>Listo, seguir eligiendo</button></div>';
  }
  function detail(id) { st.det = id; if (id) paintDetail(); el.det.style.transform = ''; el.det.classList.toggle('is-on', !!id); backdrop(); }

  /* ---------- barra fija ---------- */
  function paintTray(bump) {
    var n = count(), pct = pctFor(n), nx = nextTier(n), s = subtotal(), msg;
    el.tray.classList.toggle('is-empty', !n);
    el.fill.style.width = Math.min(n, 9) / 9 * 100 + '%';
    [].forEach.call(el.track.querySelectorAll('span'), function (m) { m.classList.toggle('is-on', n >= +m.getAttribute('data-at')); });
    if (!n) msg = 'Agrega <b>4 decants</b> y llévate <u>10% OFF</u>';
    else if (!pct) msg = '<b>' + n + (n === 1 ? ' decant' : ' decants') + '</b> · ' + (nx[0] - n === 1 ? 'te falta 1' : 'te faltan ' + (nx[0] - n)) + ' para <u>' + nx[1] + '% OFF</u>';
    else if (nx) msg = '<b>' + n + ' decants</b> · <u>' + pct + '% OFF</u> · ' + (nx[0] - n) + ' más y sube a ' + nx[1] + '%';
    else msg = '<b>' + n + ' decants</b> · <u>20% OFF</u>, el máximo';
    el.msg.innerHTML = msg;
    el.tot.innerHTML = n ? (pct ? '<s>' + money(s) + '</s>' : '') + '<b>' + money(Math.round(s * (1 - pct / 100))) + '</b>' : '';
    paintSync();
    if (el.away) el.away();
    trayH();
    if (bump && n && !calm) { el.tray.classList.remove('is-bump'); void el.tray.offsetWidth; el.tray.classList.add('is-bump'); }
  }
  /* el pie de página de la tienda crece lo que mide la barra fija, para que no lo tape */
  function trayH() { D.documentElement.style.setProperty('--scc-tray-h', (el.tray.classList.contains('is-away') ? 0 : el.tray.offsetHeight) + 'px'); }
  function celebrate(pct) {
    toast('¡Desbloqueaste <em>' + pct + '% OFF</em>!');
    el.tray.classList.remove('is-win'); void el.tray.offsetWidth; el.tray.classList.add('is-win');
    if (calm || el.sheet.classList.contains('is-on')) return;
    var colors = ['#d3f36b', '#2f4439', '#e02a20', '#ede7db', '#15181a'];
    for (var i = 0; i < 22; i++) {
      var c = D.createElement('i'); c.className = 'scc-conf'; c.style.background = colors[i % colors.length];
      c.style.setProperty('--dx', (Math.random() * 340 - 170) + 'px'); c.style.setProperty('--dy', (-80 - Math.random() * 150) + 'px'); c.style.setProperty('--r', (Math.random() * 720 - 360) + 'deg');
      el.tray.appendChild(c); (function (x) { setTimeout(function () { x.remove(); }, 1250); })(c);
    }
    if (navigator.vibrate) { try { navigator.vibrate(18); } catch (e) {} }
  }
  var toastT;
  function toast(html) { el.toast.innerHTML = html; el.toast.classList.add('is-on'); clearTimeout(toastT); toastT = setTimeout(function () { el.toast.classList.remove('is-on'); }, 2600); }

  /* ---------- hoja "Tu set" ---------- */
  function recs() {
    var inSet = {}, used = {}, out = [], g = { H: 0, M: 0, U: 0 };
    st.sel.forEach(function (l) { inSet[l.id] = 1; g[BY[l.id].g]++; });
    st.sel.forEach(function (l) { (BY[l.id].rl || []).forEach(function (h) { var it = BYH[h]; if (it && !inSet[it.id] && !used[it.id] && firstOk(it)) { used[it.id] = 1; out.push(it); } }); });
    var dom = g.H > g.M ? 'H' : g.M > g.H ? 'M' : null;
    DATA.forEach(function (it) { if (out.length < 10 && !inSet[it.id] && !used[it.id] && firstOk(it) && (!dom || it.g === dom || it.g === 'U')) { used[it.id] = 1; out.push(it); } });
    return out.slice(0, 10);
  }
  function paintSheet() {
    var n = count(), pct = pctFor(n), nx = nextTier(n), s = subtotal(), d = Math.round(s * pct) / 100;
    el.n.textContent = n + (n === 1 ? ' perfume' : ' perfumes');
    el.lines.innerHTML = st.sel.map(function (l) {
      var it = BY[l.id], v = vOf(it, l.s);
      /* tamaño = pastilla con el menú nativo del teléfono (todos los tamaños con su precio) */
      var opts = SIZES.map(function (z) { var o = vOf(it, z), av = o && o[4]; return '<option value="' + z + '"' + (z === l.s ? ' selected' : '') + (av ? '' : ' disabled') + '>' + z + ' ml · ' + (av ? money(o[2]) : 'Agotado') + '</option>'; }).join('');
      return '<div class="scc-line" data-id="' + l.id + '" data-s="' + l.s + '"><div class="scc-line-top"><img alt="" src="' + esc(img(it.i, 240)) + '">' +
        '<div><b>' + esc(it.t) + (l.q > 1 ? ' ×' + l.q : '') + '</b>' +
        '<label class="scc-size-chip"><span>' + l.s + ' ml</span><svg viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="m4 6 4 4 4-4" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
        '<select data-act="size" aria-label="Tamaño de ' + esc(it.t) + '">' + opts + '</select></label></div>' +
        '<span class="scc-line-p">' + money(v[2] * l.q) + '</span>' +
        '<button type="button" class="scc-line-x" data-act="del" aria-label="Quitar ' + esc(it.t) + '">×</button></div></div>';
    }).join('') || '<div class="scc-empty">Tu set está vacío. Agrega tu primer perfume aquí abajo.</div>';
    var list = recs(), title;
    if (!nx) title = 'Ya tienes <u>20% OFF</u>. ¿Uno más?';
    else title = (nx[0] - n === 1 ? 'Agrega <b>1 más</b>' : 'Agrega <b>' + (nx[0] - n) + ' más</b>') + ' y ' + (pct ? 'sube de ' + pct + '% a ' : 'llévate ') + '<u>' + nx[1] + '% OFF</u>';
    el.recs.hidden = !list.length;
    el.recs.innerHTML = '<p class="scc-recs-t">' + title + '</p><div class="scc-recs-rail">' + list.map(function (it) {
      var v = firstOk(it);
      var opts = SIZES.map(function (z) { var o = ok(it, z); return o ? '<option value="' + z + '"' + (z === v[1] ? ' selected' : '') + '>' + z + ' ml · ' + money(o[2]) + '</option>' : ''; }).join('');
      return '<div class="scc-rec" data-id="' + it.id + '" data-s="' + v[1] + '"><img alt="" loading="lazy" src="' + esc(img(it.i, 240)) + '"><b>' + esc(it.t) + '</b>' +
        '<label class="scc-size-chip"><span>' + v[1] + ' ml · ' + money(v[2]) + '</span><svg viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="m4 6 4 4 4-4" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
        '<select data-act="recsize" aria-label="Tamaño de ' + esc(it.t) + '">' + opts + '</select></label>' +
        '<button type="button" data-act="rec" aria-label="Agregar ' + esc(it.t) + '">+ Agregar</button></div>';
    }).join('') + '</div>';
    el.sum.innerHTML = n ? '<dl><dt>' + n + (n === 1 ? ' decant' : ' decants') + '</dt><dd>' + money(s) + '</dd>' +
      (pct ? '<dt>Buen Fin ' + pct + '% OFF</dt><dd class="is-off">−' + money(d) + '</dd>' : '') +
      '<dt>Envío a todo México</dt><dd>' + money(SHIP) + '</dd></dl>' +
      '<div class="scc-sum-mp"><span><b>Hasta 15% adicional</b> pagando con Mercado Pago y el cupón <b>BFINMP</b>. Compra mínima $2,000, tope $1,000.</span></div>' : '';
    el.foot.hidden = !n;
    el.ftot.innerHTML = (pct ? '<s>' + money(s + SHIP) + '</s>' : '') + '<b>' + money(s - d + SHIP) + '</b>';
    paintSync(); more();
  }
  /* la flecha de "hay más abajo" solo se ve mientras no se ha deslizado */
  function more() { var sc = el.scroll; el.sheet.classList.toggle('has-more', sc.scrollTop < 8 && sc.scrollHeight - sc.clientHeight > 24); }
  function backdrop() { var on = el.sheet.classList.contains('is-on') || el.det.classList.contains('is-on'); el.back.classList.toggle('is-on', on); el.tray.classList.toggle('is-under', on); }
  function sheet(on) {
    if (on) { paintSheet(); el.scroll.scrollTop = 0; } else st.open = null;
    el.sheet.style.transform = ''; el.sheet.classList.toggle('is-on', on); backdrop();
    if (on) setTimeout(more, 60);
  }
  /* deslizar hacia abajo desde el encabezado cierra la hoja */
  function swipeClose(sheetEl, handle, close) {
    var y0 = null, dy = 0;
    handle.addEventListener('touchstart', function (e) { y0 = e.touches[0].clientY; dy = 0; sheetEl.style.transition = 'none'; }, { passive: true });
    handle.addEventListener('touchmove', function (e) { if (y0 == null) return; dy = Math.max(0, e.touches[0].clientY - y0); sheetEl.style.transform = 'translate(-50%,' + dy + 'px)'; }, { passive: true });
    function end() { if (y0 == null) return; y0 = null; sheetEl.style.transition = ''; if (dy > 70) close(); else sheetEl.style.transform = ''; dy = 0; }
    handle.addEventListener('touchend', end); handle.addEventListener('touchcancel', end);
  }

  /* ---------- videos: el primero arranca solo (sin sonido) al llegar a él ---------- */
  function stopOthers(card) { [].forEach.call(root.querySelectorAll('.scc-vid'), function (c) { var v = c.querySelector('video'); if (c !== card && v) { v.pause(); c.classList.remove('is-playing', 'is-auto'); v.controls = false; } }); }
  function playVideo(card) {
    var v = card.querySelector('video'); if (!v) return;
    stopOthers(card);
    card.classList.remove('is-auto'); card.classList.add('is-playing');
    v.muted = false; v.loop = false; v.controls = true; if (card._auto) { v.currentTime = 0; card._auto = false; }
    var p = v.play(); if (p && p.catch) p.catch(function () {});
  }
  function autoVideo() {
    var card = root.querySelector('.scc-vid'); if (!card || !('IntersectionObserver' in window)) return;
    var v = card.querySelector('video');
    var observer = new IntersectionObserver(function (es) {
      es.forEach(function (e) {
        if (e.target !== card) {
          var other = e.target.querySelector('video');
          if (other && (!e.isIntersecting || e.intersectionRatio < 0.6)) other.pause();
          return;
        }
        if (e.isIntersecting && e.intersectionRatio >= 0.6) {
          if (card.classList.contains('is-playing') || root.querySelector('.scc-vid.is-playing')) return;
          v.muted = true; v.loop = true; v.setAttribute('muted', ''); card._auto = true; card.classList.add('is-auto');
          var p = v.play(); if (p && p.catch) p.catch(function () { card.classList.remove('is-auto'); });
        } else { v.pause(); }
      });
    }, { threshold: [0, 0.6] });
    [].forEach.call(root.querySelectorAll('.scc-vid'), function (item) {
      if (item.querySelector('video')) observer.observe(item);
    });
  }

  /* ---------- animaciones de entrada y contadores ---------- */
  function countUp(n) {
    var to = +n.getAttribute('data-count'), t0 = null, dur = 1400;
    function fmt(x) { return String(Math.round(x)).replace(/\B(?=(\d{3})+(?!\d))/g, ','); }
    if (calm) { n.textContent = fmt(to); return; }
    function f(t) { if (!t0) t0 = t; var k = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - k, 3); n.textContent = fmt(to * e); if (k < 1) requestAnimationFrame(f); }
    requestAnimationFrame(f);
  }
  function reveals() {
    var els = [].slice.call(root.querySelectorAll('.scc-rv,.scc-esc,[data-count]'));
    if (!('IntersectionObserver' in window)) { els.forEach(function (n) { n.classList.add('is-in'); }); return; }
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (e) {
        if (!e.isIntersecting) return;
        e.target.classList.add('is-in'); if (e.target.hasAttribute('data-count')) countUp(e.target);
        io.unobserve(e.target);
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.05 });
    els.forEach(function (n) { io.observe(n); });
    /* red de seguridad: nada se queda invisible */
    setTimeout(function () { els.forEach(function (n) { var r = n.getBoundingClientRect(); if (r.top < window.innerHeight) n.classList.add('is-in'); }); }, 2500);
  }

  /* ---------- arranque ---------- */
  function build() {
    el.grid = $('[data-scc-grid]'); el.count = $('[data-scc-count]'); el.more = $('[data-scc-more]'); el.sets = $('[data-scc-sets]'); el.tabs = $('[data-scc-tabs]');
    el.fams = $('[data-scc-fams]'); el.search = $('[data-scc-search]'); el.gen = $('[data-scc-gen]'); el.timer = $('[data-scc-timer-n]');
    var t = D.createElement('div');
    t.innerHTML = '<div class="scc-tray" data-scc-tray role="region" aria-label="Tu set">' +
      '<button type="button" class="scc-tray-top" data-scc-open aria-label="Ver tu set"><i class="scc-grab-bar" aria-hidden="true"></i><span class="scc-tray-msg" data-scc-msg aria-live="polite"></span><span class="scc-tray-r" data-scc-tot></span></button>' +
      '<div class="scc-track" data-scc-track aria-hidden="true"><div class="scc-track-bar"><i data-scc-fill></i></div>' +
      '<span data-at="4" style="left:44.44%">4 = 10%</span><span data-at="6" style="left:66.66%">6 = 15%</span><span data-at="9" style="left:100%">9 = 20%</span></div>' +
      '<div class="scc-err" data-scc-err hidden>No pudimos guardar tu set. Revisa tu conexión.</div><button type="button" class="scc-cta" data-scc-cta disabled></button></div>' +
      '<div class="scc-backdrop" data-scc-back></div>' +
      '<div class="scc-sheet scc-sheet--set" data-scc-sheet role="dialog" aria-label="Tu set">' +
      '<div class="scc-sheet-top" data-scc-grab><i class="scc-grab-bar" aria-hidden="true"></i><div class="scc-sheet-h"><b>Tu set</b><span class="scc-n" data-scc-n></span><button type="button" class="scc-x-btn" data-scc-close aria-label="Cerrar">×</button></div></div>' +
      '<div class="scc-sync" data-scc-bar hidden><i></i></div>' +
      '<div class="scc-scroll" data-scc-scroll><div data-scc-lines></div><div class="scc-recs" data-scc-recs hidden></div><div class="scc-sum" data-scc-sum></div></div>' +
      '<div class="scc-foot" data-scc-foot><div class="scc-foot-t"><span>Total con envío</span><span class="scc-foot-n" data-scc-ftot></span></div>' +
      '<div class="scc-err" data-scc-err2 hidden>No pudimos guardar tu set. Revisa tu conexión.</div><button type="button" class="scc-cta" data-scc-cta2>Pagar ahora</button></div></div>' +
      '<div class="scc-sheet" data-scc-det role="dialog" aria-label="Detalle del perfume"><div class="scc-det-grab" data-scc-det-grab><i class="scc-grab-bar" aria-hidden="true"></i></div><button type="button" class="scc-x-btn scc-det-x" data-scc-det-close aria-label="Cerrar">×</button><div class="scc-det" data-scc-det-body></div></div>' +
      '<div class="scc-toast" data-scc-toast role="status"></div>';
    while (t.firstChild) D.body.appendChild(t.firstChild);
    el.tray = $d('[data-scc-tray]'); el.msg = $d('[data-scc-msg]'); el.tot = $d('[data-scc-tot]'); el.track = $d('[data-scc-track]'); el.fill = $d('[data-scc-fill]');
    el.cta = $d('[data-scc-cta]'); el.cta2 = $d('[data-scc-cta2]'); el.err = $d('[data-scc-err]'); el.err2 = $d('[data-scc-err2]'); el.back = $d('[data-scc-back]');
    el.sheet = $d('[data-scc-sheet]'); el.lines = $d('[data-scc-lines]'); el.sum = $d('[data-scc-sum]'); el.recs = $d('[data-scc-recs]'); el.scroll = $d('[data-scc-scroll]');
    el.n = $d('[data-scc-n]'); el.bar = $d('[data-scc-bar]'); el.foot = $d('[data-scc-foot]'); el.ftot = $d('[data-scc-ftot]');
    el.det = $d('[data-scc-det]'); el.detBody = $d('[data-scc-det-body]'); el.toast = $d('[data-scc-toast]');

    D.addEventListener('pointerdown', function (e) { lastTap = { x: e.clientX, y: e.clientY }; }, { passive: true });
    root.addEventListener('click', function (e) {
      var b;
      if ((b = e.target.closest('[data-mode]'))) { st.mode = b.getAttribute('data-mode'); paintMode(); if (st.mode === 'mio') paintCards(true); else paintSets(); el.away(); return; }
      if ((b = e.target.closest('[data-tab]'))) { st.tab = b.getAttribute('data-tab'); paintSets(); return; }
      if ((b = e.target.closest('[data-buy]'))) { buySet(+b.getAttribute('data-buy')); return; }
      if ((b = e.target.closest('[data-fam]'))) { st.fam = b.getAttribute('data-fam'); st.shown = PAGE; [].forEach.call(el.fams.children, function (c) { c.classList.toggle('is-on', c === b); }); paintCards(true); return; }
      if ((b = e.target.closest('[data-gen]'))) { st.gen = b.getAttribute('data-gen'); st.shown = PAGE; [].forEach.call(el.gen.children, function (c) { c.classList.toggle('is-on', c === b); }); paintCards(true); return; }
      if ((b = e.target.closest('[data-scc-go]'))) { e.preventDefault(); var to = root.querySelector(b.getAttribute('data-scc-go')); if (to) to.scrollIntoView({ behavior: 'smooth', block: 'start' }); return; }
      if ((b = e.target.closest('[data-video]'))) { playVideo(b.closest('.scc-vid')); return; }
      if ((b = e.target.closest('[data-act]')) && el.grid.contains(b)) {
        var id = +b.closest('[data-id]').getAttribute('data-id'), a = b.getAttribute('data-act');
        if (a === 'open') detail(id); else if (a === 'toggle') toggle(id, b.getAttribute('data-s'));
      }
    });
    el.more.addEventListener('click', function () { st.shown += PAGE; paintCards(false); });
    el.search.addEventListener('input', function () { st.q = el.search.value; st.shown = PAGE; paintCards(false); });
    $d('[data-scc-open]').addEventListener('click', function () { sheet(true); });
    el.back.addEventListener('click', function () { sheet(false); detail(null); });
    $d('[data-scc-close]').addEventListener('click', function () { sheet(false); });
    el.det.addEventListener('click', function (e) {
      var b;
      if (e.target.closest('[data-scc-det-close]')) { detail(null); return; }
      if ((b = e.target.closest('[data-act="toggle"]'))) toggle(st.det, b.getAttribute('data-s'));
    });
    D.addEventListener('keydown', function (e) { if (e.key === 'Escape') { sheet(false); detail(null); } });
    el.cta.addEventListener('click', pay); el.cta2.addEventListener('click', pay);
    el.sheet.addEventListener('click', function (e) {
      var b = e.target.closest('[data-act]'); if (!b) return;
      var row = b.closest('[data-id]'), id = +row.getAttribute('data-id'), s = row.getAttribute('data-s'), a = b.getAttribute('data-act');
      if (a === 'del') drop(id, s); else if (a === 'rec') add(id, s);
    });
    el.sheet.addEventListener('change', function (e) {
      var rs = e.target.closest('select[data-act="recsize"]');
      if (rs) { var rc = rs.closest('.scc-rec'), ro = ok(BY[+rc.getAttribute('data-id')], rs.value); if (ro) { rc.setAttribute('data-s', rs.value); rc.querySelector('.scc-size-chip span').textContent = rs.value + ' ml · ' + money(ro[2]); } return; }
      var sel = e.target.closest('select[data-act="size"]'); if (!sel) return;
      var row = sel.closest('[data-id]'); resize(+row.getAttribute('data-id'), row.getAttribute('data-s'), sel.value);
    });
    el.scroll.addEventListener('scroll', more, { passive: true });
    swipeClose(el.sheet, $d('[data-scc-grab]'), function () { sheet(false); });
    swipeClose(el.det, $d('[data-scc-det-grab]'), function () { detail(null); });
    /* deslizar la barra hacia arriba abre "Tu set" */
    var ty = null; el.tray.addEventListener('touchstart', function (e) { ty = e.touches[0].clientY; }, { passive: true });
    el.tray.addEventListener('touchend', function (e) { if (ty != null && ty - e.changedTouches[0].clientY > 36 && count()) sheet(true); ty = null; });
    /* el ícono de la bolsa del encabezado abre "Tu set" (el cajón de la tienda no se entera de lo que se agrega aquí) */
    D.addEventListener('click', function (e) {
      var a = e.target.closest('.sc-header-actions [data-target="#modal-cart"], .sc-header-actions a[href*="/comprar"]');
      if (a && count()) { e.preventDefault(); e.stopPropagation(); sheet(true); }
    }, true);
    /* la barra se esconde mientras el set está vacío (en "ya armado" siempre; en "a mi gusto" solo en la portada) */
    el.away = function () { var a = !count() && (st.mode === 'sets' || (window.pageYOffset || 0) < 420); if (a !== el.tray.classList.contains('is-away')) { el.tray.classList.toggle('is-away', a); trayH(); } };
    window.addEventListener('scroll', el.away, { passive: true }); window.addEventListener('resize', trayH); el.away(); trayH();
    tick(); setInterval(tick, 1000);
  }

  reveals();
  fetch(root.getAttribute('data-scc'), { credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (j) {
    DATA = (j.items || []).filter(function (it) { return it.vs.some(function (v) { return v[4]; }); });
    if (j.tiers && j.tiers.length) TIERS = j.tiers;
    IC = j.ic || {}; ICG = j.icg || 9;
    var ar = root.getAttribute('data-aromas'); if (ar) { D.documentElement.style.setProperty('--scc-aromas', 'url("' + ar + '")'); D.documentElement.style.setProperty('--scc-ic-g', ICG * 100 + '%'); }
    DATA.forEach(function (it) { BY[it.id] = it; BYH[it.h] = it; it.vs.forEach(function (v) { VAR[v[0]] = { it: it, s: v[1] }; }); });
    DATA.slice(0, 8).forEach(function (it) { if (it.p > 0) TOP[it.id] = 1; });
    /* el carrito real lo expone la tienda en LS.cart; si aún no está, se espera un momento */
    var tries = 0;
    (function start() {
      if (!(window.LS && LS.cart && LS.cart.items) && tries++ < 30) { setTimeout(start, 100); return; }
      try { readCart(window.LS && LS.cart && LS.cart.items, 'item_id'); } catch (e) { real = {}; }
      selFromCart();
      build(); st.tier = pctFor(count());
      paintMode(); paintSets(); paintCards(false); paintTray(false); autoVideo();
      confirmCart();
    })();
  }).catch(function () {
    var g = $('[data-scc-grid]'); if (g) g.innerHTML = '<div class="scc-empty">No pudimos cargar los perfumes. Recarga la página.</div>';
  });
})();
