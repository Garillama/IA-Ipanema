"""Worker/adapter/schema pipeline with mocked transport: zero model or store access."""
import json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from tests.support import ROOT
from ipanema.core import Project
from ipanema.orchestration import adapters,engine

GOOD={'decision':'approve','summary':'Synthetic','evidence':[],'changes':[]}
class SmokeContract(unittest.TestCase):
 def invoke(self,payload):
  with tempfile.TemporaryDirectory()as tmp:
   tree=Path(tmp)/'fixture';tree.mkdir();(tree/'fixture.txt').write_text('Synthetic')
   task={'id':'smoke','role':'smoke','agent':'claude','tier':'fast','read_files':['fixture.txt'],'allowed_files':[]}
   observed={}
   def fake(args,prompt,view,**kwargs):
    observed['args']=args;observed['schema_exists']=(view/'council-response.schema.json').is_file()
    return {'exit_code':0,'stdout':json.dumps(payload),'stderr':'','process_reaped':True,'context_complete':True}
   with patch.object(adapters.shutil,'which',return_value='/usr/bin/true'),patch('ipanema.orchestration.isolation.run_isolated',side_effect=fake):
    result=engine._worker_once(Project(ROOT),{},task,tree,[],{},frozen_prompt='Synthetic fixture')
   return result,task,observed
 def test_smoke_uses_native_schema_and_same_safety_flags(self):
  result,task,seen=self.invoke({'type':'result','subtype':'success','structured_output':GOOD})
  self.assertEqual(result,GOOD);self.assertIn('--json-schema',seen['args']);self.assertTrue(seen['schema_exists'])
  self.assertIn('--restricted',seen['args']);self.assertIn('--strict-mcp-config',seen['args']);self.assertEqual(task['execution']['structured_output'],'native_schema')
 def test_missing_required_field_rejected_by_worker(self):
  with self.assertRaises(adapters.ResponseContractError):self.invoke({'type':'result','structured_output':{'decision':'approve','changes':[]}})
 def test_smoke_cannot_return_writes(self):
  with self.assertRaises(adapters.ResponseContractError):self.invoke({'type':'result','structured_output':{**GOOD,'changes':['forbidden']}})
 def test_invalid_json_text_never_bypasses_pipeline(self):
  with self.assertRaises(adapters.ResponseContractError):self.invoke({'type':'result','result':'```json\n{}\n```'})
 def test_extra_fields_rejected(self):
  with self.assertRaises(adapters.ResponseContractError):self.invoke({'type':'result','structured_output':{**GOOD,'private':'must not be accepted'}})
