"""Synthetic transport boundaries; never provider responses or approval evidence."""
import json,unittest
from tests.support import ROOT
from ipanema.orchestration import adapters

GOOD={'decision':'approve','summary':'Synthetic','evidence':[],'changes':[]}
def frame(text):return json.dumps({'type':'result','subtype':'success','result':text})
class Transport(unittest.TestCase):
 def reject(self,raw,strict=True):
  with self.assertRaises(adapters.ResponseContractError):adapters.parse_response('claude',raw,strict=strict)
 def test_valid_pretty_envelope(self):
  self.assertEqual(adapters.parse_response('claude',json.dumps({'type':'result','result':json.dumps(GOOD,indent=2)},indent=2),strict=True),GOOD)
 def test_valid_provider_event_sequence(self):
  raw=json.dumps({'type':'system','subtype':'init'})+'\n'+frame(json.dumps(GOOD))
  self.assertEqual(adapters.parse_response('claude',raw,strict=True),GOOD)
 def test_native_structured_output_authoritative_over_free_text(self):
  raw=json.dumps({'type':'result','subtype':'success','result':'Non-JSON metadata','structured_output':GOOD})
  self.assertEqual(adapters.parse_response('claude',raw,strict=True),GOOD)
 def test_markdown_is_not_business_json_in_either_mode(self):
  for strict in [True,False]:
   with self.subTest(strict=strict):self.reject(frame('```json\n'+json.dumps(GOOD)+'\n```'),strict)
 def test_incomplete_business_json(self):self.reject(frame('{"decision":"approve",'))
 def test_business_text_after_json(self):self.reject(frame(json.dumps(GOOD)+'\nExtra text'))
 def test_business_multiple_objects(self):self.reject(frame(json.dumps(GOOD)+'\n'+json.dumps(GOOD)))
 def test_transport_multiple_bare_objects(self):self.reject(json.dumps(GOOD)+'\n'+json.dumps(GOOD))
 def test_transport_garbage_after_envelope(self):self.reject(frame(json.dumps(GOOD))+'\nPrivate trailing text')
 def test_transport_incomplete_tail(self):self.reject(frame(json.dumps(GOOD))+'\n{"type":')
 def test_multiple_final_envelopes_ambiguous(self):self.reject(frame(json.dumps(GOOD))+'\n'+frame(json.dumps(GOOD)))
 def test_last_invalid_payload_cannot_hide_behind_earlier_valid_payload(self):self.reject(frame(json.dumps(GOOD))+'\n'+frame('{"decision":'))
 def test_duplicate_keys_rejected_in_both_modes(self):
  for strict in [True,False]:
   with self.subTest(strict=strict):self.reject(frame('{"decision":"blocked","decision":"approve","changes":[]}'),strict)
 def test_nonfinite_numbers_rejected_in_both_modes(self):
  for strict in [True,False]:
   with self.subTest(strict=strict):self.reject(frame('{"decision":"approve","confidence":NaN,"changes":[]}'),strict)
 def test_nested_truncation_signal_rejected(self):
  delta={'type':'stream_event','event':{'type':'message_delta','delta':{'stop_reason':'max_tokens'}}}
  self.reject(json.dumps(delta)+'\n'+frame(json.dumps(GOOD)))
 def test_native_invalid_structured_output_not_text_fallback(self):self.reject(json.dumps({'type':'result','structured_output':'invalid','result':json.dumps(GOOD)}))
 def test_provider_error_after_good_result(self):self.reject(frame(json.dumps(GOOD))+'\n'+json.dumps({'type':'result','is_error':True}))
 def test_tool_execution_after_good_result(self):
  self.reject(frame(json.dumps(GOOD))+'\n'+json.dumps({'type':'item.completed','item':{'type':'command_execution'}}))
 def test_schema_mismatch_remains_separate_from_syntax(self):
  value=adapters.parse_response('claude',frame(json.dumps({'decision':'approve','changes':[]})),strict=True)
  with self.assertRaises(adapters.ResponseContractError)as cm:adapters.validate_schema(value,{'type':'object','required':['summary'],'properties':{}})
  self.assertEqual(cm.exception.diagnostic['category'],'missing_field')
